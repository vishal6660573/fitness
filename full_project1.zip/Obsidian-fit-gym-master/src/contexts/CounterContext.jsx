// Create a context object
import { createContext, useState, useCallback, useEffect } from "react";

export const counterContextObj = createContext();

function CounterContext({ children }) {
  // Enhanced state with additional features
  const [counter, setCounter] = useState(100);
  const [history, setHistory] = useState([100]);
  const [isLoading, setIsLoading] = useState(false);
  const [step, setStep] = useState(1);
  const [min, setMin] = useState(0);
  const [max, setMax] = useState(1000);

  // Enhanced counter operations with useCallback for performance
  const increment = useCallback(() => {
    setCounter(prev => {
      const newValue = Math.min(prev + step, max);
      if (newValue !== prev) {
        setHistory(prevHistory => [...prevHistory, newValue]);
      }
      return newValue;
    });
  }, [step, max]);

  const decrement = useCallback(() => {
    setCounter(prev => {
      const newValue = Math.max(prev - step, min);
      if (newValue !== prev) {
        setHistory(prevHistory => [...prevHistory, newValue]);
      }
      return newValue;
    });
  }, [step, min]);

  const incrementBy = useCallback((amount) => {
    if (typeof amount !== 'number' || isNaN(amount)) return;
    setCounter(prev => {
      const newValue = Math.min(prev + amount, max);
      if (newValue !== prev) {
        setHistory(prevHistory => [...prevHistory, newValue]);
      }
      return newValue;
    });
  }, [max]);

  const decrementBy = useCallback((amount) => {
    if (typeof amount !== 'number' || isNaN(amount)) return;
    setCounter(prev => {
      const newValue = Math.max(prev - amount, min);
      if (newValue !== prev) {
        setHistory(prevHistory => [...prevHistory, newValue]);
      }
      return newValue;
    });
  }, [min]);

  const reset = useCallback(() => {
    setCounter(100);
    setHistory([100]);
  }, []);

  const setCounterValue = useCallback((value) => {
    if (typeof value !== 'number' || isNaN(value)) return;
    const clampedValue = Math.max(min, Math.min(value, max));
    setCounter(clampedValue);
    setHistory(prevHistory => [...prevHistory, clampedValue]);
  }, [min, max]);

  // Async operation example
  const asyncIncrement = useCallback(async (amount = 1) => {
    setIsLoading(true);
    try {
      // Simulate async operation (e.g., API call)
      await new Promise(resolve => setTimeout(resolve, 1000));
      incrementBy(amount);
    } catch (error) {
      console.error('Async increment failed:', error);
    } finally {
      setIsLoading(false);
    }
  }, [incrementBy]);

  // Batch operations
  const batchOperation = useCallback((operations) => {
    if (!Array.isArray(operations)) return;
    
    operations.forEach(operation => {
      switch (operation.type) {
        case 'increment':
          increment();
          break;
        case 'decrement':
          decrement();
          break;
        case 'incrementBy':
          incrementBy(operation.amount);
          break;
        case 'decrementBy':
          decrementBy(operation.amount);
          break;
        case 'set':
          setCounterValue(operation.value);
          break;
        default:
          console.warn('Unknown operation type:', operation.type);
      }
    });
  }, [increment, decrement, incrementBy, decrementBy, setCounterValue]);

  // Utility functions
  const getCounterStats = useCallback(() => {
    return {
      current: counter,
      min: Math.min(...history),
      max: Math.max(...history),
      average: history.reduce((sum, val) => sum + val, 0) / history.length,
      changes: history.length - 1,
      isAtMin: counter === min,
      isAtMax: counter === max
    };
  }, [counter, history, min, max]);

  const canIncrement = counter < max;
  const canDecrement = counter > min;

  // Auto-save to localStorage (optional feature)
  useEffect(() => {
    const savedCounter = localStorage.getItem('counterValue');
    if (savedCounter) {
      const parsedValue = parseInt(savedCounter, 10);
      if (!isNaN(parsedValue)) {
        setCounter(parsedValue);
        setHistory([parsedValue]);
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('counterValue', counter.toString());
  }, [counter]);

  // Context value with all enhanced features
  const contextValue = {
    // Original state (maintaining backward compatibility)
    counter,
    setCounter,
    
    // Enhanced state
    history,
    isLoading,
    step,
    setStep,
    min,
    setMin,
    max,
    setMax,
    
    // Enhanced operations
    increment,
    decrement,
    incrementBy,
    decrementBy,
    reset,
    setCounterValue,
    asyncIncrement,
    batchOperation,
    
    // Utility functions
    getCounterStats,
    canIncrement,
    canDecrement,
    
    // History operations
    undo: () => {
      if (history.length > 1) {
        const newHistory = [...history];
        newHistory.pop();
        const previousValue = newHistory[newHistory.length - 1];
        setCounter(previousValue);
        setHistory(newHistory);
      }
    },
    clearHistory: () => setHistory([counter]),
    
    // Validation helpers
    isValidValue: (value) => {
      return typeof value === 'number' && !isNaN(value) && value >= min && value <= max;
    }
  };

  return (
    <counterContextObj.Provider value={contextValue}>
      {children}
    </counterContextObj.Provider>
  );
}

export default CounterContext;