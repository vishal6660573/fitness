import { createContext, useState, useEffect } from "react";

export const loginContextObj = createContext();

function LoginContext({ children }) {
  // Initialize state with localStorage values if available
  const [userLoginStatus, setUserLoginStatus] = useState(() => {
    return localStorage.getItem('userLoginStatus') === 'true';
  });
  const [currentUser, setCurrentUser] = useState(() => {
    const savedUser = localStorage.getItem('currentUser');
    return savedUser ? JSON.parse(savedUser) : null;
  });
  const [loginErr, setLoginErr] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  // Persist state to localStorage when it changes
  useEffect(() => {
    localStorage.setItem('userLoginStatus', userLoginStatus);
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
  }, [userLoginStatus, currentUser]);

  async function handleUserLogin({ username, password }) {
    if (!username || !password) {
      setLoginErr({ message: "Username and password are required" });
      return;
    }

    setLoginErr(null);
    setIsLoading(true);

    try {
      const response = await fetch(
        `http://localhost:3000/users?username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`,
        { method: "GET" }
      );

      if (!response.ok) {
        throw new Error(`Login failed: ${response.status}`);
      }

      const usersList = await response.json();

      if (!usersList || usersList.length === 0) {
        throw new Error("Invalid username or password");
      }

      const user = usersList[0];
      if (!user.id || !user.username) {
        throw new Error("Invalid user data received");
      }

      setUserLoginStatus(true);
      setCurrentUser(user);
      setLoginErr(null);
      return true; // Indicate success
    } catch (err) {
      console.error("Login error:", err);
      setLoginErr({ 
        message: err.message || "An error occurred during login. Please try again." 
      });
      return false; // Indicate failure
    } finally {
      setIsLoading(false);
    }
  }

  function userLogout() {
    localStorage.removeItem('userLoginStatus');
    localStorage.removeItem('currentUser');
    setCurrentUser(null);
    setUserLoginStatus(false);
    setLoginErr(null);
  }

  function clearLoginError() {
    setLoginErr(null);
  }

  // Function to update user data (for profile edits)
  async function updateUserData(updatedUser) {
    try {
      const response = await fetch(`http://localhost:3000/users/${updatedUser.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedUser)
      });

      if (!response.ok) {
        throw new Error(`Failed to update user: ${response.status}`);
      }

      const user = await response.json();
      setCurrentUser(user);
      return true;
    } catch (err) {
      console.error("Update error:", err);
      setLoginErr({
        message: err.message || "Failed to update user data"
      });
      return false;
    }
  }

  const contextValue = {
    handleUserLogin,
    userLogout,
    clearLoginError,
    updateUserData,
    userLoginStatus,
    currentUser,
    loginErr,
    isLoading,
    setCurrentUser
  };

  return (
    <loginContextObj.Provider value={contextValue}>
      {children}
    </loginContextObj.Provider>
  );
}

export default LoginContext;