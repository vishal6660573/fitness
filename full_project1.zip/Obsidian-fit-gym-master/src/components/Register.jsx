import { useForm } from 'react-hook-form';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { authAPI } from '../services/api.js';
import './Register.css';

function Register() {
  const { register, handleSubmit, formState: { errors } } = useForm();
  const navigate = useNavigate();
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  async function handleFormSubmit(userData) {
    setIsLoading(true);
    setError(null);

    try {
      // Use the new API service
      const response = await authAPI.register({
        username: userData.username,
        email: userData.email,
        password: userData.password,
        dob: userData.dob
      });

      if (response.success) {
        // Registration successful, redirect to login
        navigate("/login");
      } else {
        setError(response.message || "Registration failed. Please try again.");
      }
    } catch (err) {
      console.error("Registration error:", err);
      
      // Handle specific validation errors
      if (err.message && err.message.includes('Validation failed')) {
        if (err.errors && err.errors.length > 0) {
          const errorMessages = err.errors.map(e => e.message).join(', ');
          setError(errorMessages);
        } else {
          setError(err.message);
        }
      } else {
        setError(err.message || "Registration failed. Please try again.");
      }
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="register-container">
      <div className="welcome-header">
        <h1 className="welcome-title">Welcome Aboard!</h1>
        <p className="welcome-subtitle">Create your account and start your journey</p>
      </div>

      <div className="form-container">
        <div className="form-card">
          {error && <div className="error-message">{error}</div>}
          
          <form onSubmit={handleSubmit(handleFormSubmit)}>
            <div className="form-group">
              <label htmlFor="username" className="form-label">
                Username
              </label>
              <input
                type="text"
                {...register("username", {
                  required: "Username is required",
                  minLength: {
                    value: 3,
                    message: "Username must be at least 3 characters"
                  }
                })}
                id="username"
                className="form-input"
                placeholder="Enter your username"
              />
              {errors.username && (
                <div className="error-message">{errors.username.message}</div>
              )}
            </div>

            <div className="form-group">
              <label htmlFor="email" className="form-label">
                Email
              </label>
              <input
                type="email"
                {...register("email", {
                  required: "Email is required",
                  pattern: {
                    value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                    message: "Please enter a valid email address"
                  }
                })}
                id="email"
                className="form-input"
                placeholder="Enter your email address"
              />
              {errors.email && (
                <div className="error-message">{errors.email.message}</div>
              )}
            </div>

            <div className="form-group">
              <label htmlFor="password" className="form-label">
                Password
              </label>
              <input
                type="password"
                {...register("password", {
                  required: "Password is required",
                  minLength: {
                    value: 6,
                    message: "Password must be at least 6 characters"
                  }
                })}
                id="password"
                className="form-input"
                placeholder="Create a secure password"
              />
              {errors.password && (
                <div className="error-message">{errors.password.message}</div>
              )}
              <div className="password-requirements">
                <small>Password must contain:</small>
                <ul>
                  <li>At least 6 characters</li>
                  <li>At least one uppercase letter (A-Z)</li>
                  <li>At least one lowercase letter (a-z)</li>
                  <li>At least one number (0-9)</li>
                </ul>
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="dob" className="form-label">
                Date of Birth
              </label>
              <input
                type="date"
                {...register("dob", {
                  required: "Date of birth is required"
                })}
                id="dob"
                className="form-input"
              />
              {errors.dob && (
                <div className="error-message">{errors.dob.message}</div>
              )}
            </div>

            <button
              className="submit-button"
              type="submit"
              disabled={isLoading}
            >
              {isLoading ? "Creating Account..." : "Create Account"}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Register;