import React, { useState, useEffect } from 'react';
import './Home.css';

function Home() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [filteredCourses, setFilteredCourses] = useState([]);

  // Sample course data
  const courses = [
    {
      id: 1,
      title: "Ultimate Strength Training Plan",
      trainer: "Alex Johnson, Certified Fitness Expert",
      rating: 4.9,
      reviews: 15200,
      price: 799,
      originalPrice: 1999,
      image: "https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
      category: "Strength Training",
      description: "Build muscle and increase strength with our comprehensive training program.",
      duration: "12 weeks",
      level: "Intermediate"
    },
    {
      id: 2,
      title: "High-Intensity Interval Training (HIIT)",
      trainer: "Sarah Lee, HIIT Specialist",
      rating: 4.8,
      reviews: 12345,
      price: 599,
      originalPrice: 1499,
      image: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1420&q=80",
      category: "HIIT Workouts",
      description: "Burn calories fast with high-intensity interval training workouts.",
      duration: "8 weeks",
      level: "Beginner"
    },
    {
      id: 3,
      title: "Yoga and Flexibility Masterclass",
      trainer: "Emma Davis, Yoga Instructor",
      rating: 4.9,
      reviews: 9876,
      price: 499,
      originalPrice: 1299,
      image: "https://images.unsplash.com/photo-1506629905189-126d83d4df35?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
      category: "Yoga & Meditation",
      description: "Improve flexibility and find inner peace through yoga practice.",
      duration: "10 weeks",
      level: "All Levels"
    },
    {
      id: 4,
      title: "Full-Body Fitness: 21-Day Challenge",
      trainer: "Michael Scott, Fitness Coach",
      rating: 4.7,
      reviews: 8567,
      price: 799,
      originalPrice: 1799,
      image: "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
      category: "Fitness Programs",
      description: "Transform your body in just 21 days with our complete fitness program.",
      duration: "3 weeks",
      level: "Intermediate"
    },
    {
      id: 5,
      title: "Cardio Blast Bootcamp",
      trainer: "Lisa Rodriguez, Cardio Expert",
      rating: 4.6,
      reviews: 6543,
      price: 549,
      originalPrice: 1199,
      image: "https://images.unsplash.com/photo-1571019613914-85f342c6a11e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
      category: "Cardio Sessions",
      description: "High-energy cardio workouts to boost your cardiovascular health.",
      duration: "6 weeks",
      level: "Beginner"
    },
    {
      id: 6,
      title: "Nutrition Mastery Program",
      trainer: "Dr. James Wilson, Nutritionist",
      rating: 4.8,
      reviews: 4321,
      price: 899,
      originalPrice: 1599,
      image: "https://images.unsplash.com/photo-1490645935967-10de6ba17061?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
      category: "Nutrition Plans",
      description: "Learn the science of nutrition and create sustainable eating habits.",
      duration: "8 weeks",
      level: "All Levels"
    }
  ];

  const categories = [
    { name: "Yoga & Meditation", participants: "1.5M+", icon: "🧘‍♀️" },
    { name: "Strength Training", participants: "2.3M+", icon: "💪" },
    { name: "HIIT Workouts", participants: "1.2M+", icon: "🔥" },
    { name: "Cardio Sessions", participants: "3M+", icon: "🏃‍♂️" },
    { name: "Nutrition Plans", participants: "800K+", icon: "🥗" },
    { name: "Personal Training", participants: "600K+", icon: "👨‍🏫" },
    { name: "Weight Loss Programs", participants: "1.8M+", icon: "⚖️" },
    { name: "Group Classes", participants: "2.5M+", icon: "👥" }
  ];

  const navItems = [
    "All Programs",
    "Fitness Programs",
    "Yoga & Meditation", 
    "Strength Training",
    "HIIT Workouts",
    "Nutrition Plans",
    "Cardio Sessions"
  ];

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleCategoryClick = (category) => {
    setSelectedCategory(category === selectedCategory ? '' : category);
  };

  const handleLearnMoreClick = () => {
    window.scrollTo({ top: document.getElementById('programs-section').offsetTop, behavior: 'smooth' });
  };

  const handleCourseClick = (courseId) => {
    alert(`Course ${courseId} selected! Full course details and enrollment coming soon.`);
  };

  const handleGetStartedClick = () => {
    window.scrollTo({ top: document.getElementById('programs-section').offsetTop, behavior: 'smooth' });
  };

  const renderStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push('★');
    }
    if (hasHalfStar) {
      stars.push('☆');
    }
    
    return stars.join('');
  };

  // Filter courses based on search term and selected category
  useEffect(() => {
    let filtered = courses;

    if (searchTerm) {
      filtered = filtered.filter(course => 
        course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        course.trainer.toLowerCase().includes(searchTerm.toLowerCase()) ||
        course.category.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (selectedCategory && selectedCategory !== 'All Programs') {
      filtered = filtered.filter(course => course.category === selectedCategory);
    }

    setFilteredCourses(filtered);
  }, [searchTerm, selectedCategory]);

  useEffect(() => {
    // Add entrance animations
    const elements = document.querySelectorAll('.border, .box, .hero-content');
    elements.forEach((el, index) => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(20px)';
      
      setTimeout(() => {
        el.style.transition = 'all 0.6s ease';
        el.style.opacity = '1';
        el.style.transform = 'translateY(0)';
      }, index * 100);
    });
  }, []);

  return (
    <div className='tp'>
      {/* Header */}
      <header className="header">
        <nav className="navbar">
          <div className="brand">
            <h1 className="udemy">Obsidian Fit</h1>
          </div>
          <ul className="nav-links">
            <li><a href="#programs">Programs</a></li>
            <li><a href="#nutrition">Nutrition</a></li>
            <li><a href="#trainers">Trainers</a></li>
            <li><a href="#community">Community</a></li>
          </ul>
          <div className="search-container">
            <input 
              type="text" 
              className="search" 
              placeholder="Search for fitness programs"
              value={searchTerm}
              onChange={handleSearch}
            />
          </div>
        </nav>
      </header>

      {/* Promotional Banner */}
      <div className="up">
        <h2 className="nwe">🎯 Limited Time Offer!</h2>
        <p className="uphead">
          Get unlimited access to premium fitness programs starting from ₹699/month. Transform your fitness journey today!
        </p>
        <button className="promo-btn" onClick={handleGetStartedClick}>
          Get Started Now
        </button>
      </div>

      {/* Hero Section */}
      <div className="fb">
        <div className="content hero-content">
          <h2 className="vt">
            Transform Your Body,<br />
            Transform Your Life
          </h2>
          <p className="para">
            Join thousands of fitness enthusiasts with our premium collection of<br />
            workout programs, nutrition plans, and expert guidance.
          </p>
          <div className="hero-stats">
            <div className="stat">
              <span className="stat-number">100+</span>
              <span className="stat-label">Programs</span>
            </div>
            <div className="stat">
              <span className="stat-number">50K+</span>
              <span className="stat-label">Members</span>
            </div>
            <div className="stat">
              <span className="stat-number">4.8★</span>
              <span className="stat-label">Rating</span>
            </div>
          </div>
          <button className="btn" onClick={handleLearnMoreClick}>
            Explore Programs
          </button>
        </div>
        <div className="gir">
          <img
            src="https://images.unsplash.com/photo-1571019613914-85f342c6a11e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
            className="img"
            alt="Fitness Training"
          />
        </div>
      </div>

      {/* Main Content */}
      <div className="main2" id="programs-section">
        <div id="jat">
          <h1 id="head">Everything You Need to Achieve Your Goals</h1>
          <p id="para">
            From high-intensity workouts to mindful yoga sessions, Obsidian Fit provides comprehensive fitness solutions for every lifestyle and goal.
          </p>
          <div className="filter-section">
            <h3>Browse by Category:</h3>
            <ul id="list">
              {navItems.map((item, index) => (
                <li 
                  key={index}
                  className={selectedCategory === item ? 'active' : ''}
                  onClick={() => handleCategoryClick(item)}
                >
                  {item}
                </li>
              ))}
            </ul>
          </div>
          <hr className="section-divider" />
        </div>

        <div id="color">
          <div id="space">
            <h2 className="section-title">Popular Categories</h2>
            <ul id="box">
              {categories.map((category, index) => (
                <li 
                  key={index} 
                  className={`box ${selectedCategory === category.name ? 'active' : ''}`}
                  onClick={() => handleCategoryClick(category.name)}
                >
                  <div className="category-icon">{category.icon}</div>
                  <h3 className="wt">{category.name}</h3>
                  <p className="re">{category.participants} participants</p>
                </li>
              ))}
            </ul>
          </div>

          {/* Course Cards */}
          <div className="course-section">
            <h2 className="section-title">
              {selectedCategory && selectedCategory !== 'All Programs' 
                ? `${selectedCategory} Programs` 
                : 'Featured Programs'}
              {searchTerm && ` - Search: "${searchTerm}"`}
            </h2>
            
            {filteredCourses.length > 0 ? (
              <div className="course">
                {filteredCourses.map((course) => (
                  <div 
                    key={course.id} 
                    className="border"
                    onClick={() => handleCourseClick(course.id)}
                  >
                    <img
                      src={course.image}
                      className="girl"
                      alt={course.title}
                    />
                    <div className="course-content">
                      <h3>{course.title}</h3>
                      <p className="trainer-name">{course.trainer}</p>
                      <p className="course-description">{course.description}</p>
                      
                      <div className="course-details">
                        <span className="duration">⏱️ {course.duration}</span>
                        <span className="level">📈 {course.level}</span>
                      </div>
                      
                      <div className="rating-section">
                        <span className="rating-number">{course.rating}</span>
                        <div className="stars" title={`${course.rating} stars`}>
                          {renderStars(course.rating)}
                        </div>
                        <span className="reviews">({course.reviews.toLocaleString()} reviews)</span>
                      </div>
                      
                      <div className="price-section">
                        <span className="current-price">₹{course.price}</span>
                        <span className="original-price">₹{course.originalPrice}</span>
                        <span className="discount">
                          {Math.round((1 - course.price / course.originalPrice) * 100)}% OFF
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="no-results">
                <h3>No programs found</h3>
                <p>Try adjusting your search or filter criteria.</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="footer">
        <div className="footer-content">
          <div className="footer-section">
            <h3>Obsidian Fit</h3>
            <p>Your journey to a healthier, stronger you starts here.</p>
          </div>
          <div className="footer-section">
            <h4>Quick Links</h4>
            <ul>
              <li><a href="#programs">Programs</a></li>
              <li><a href="#nutrition">Nutrition</a></li>
              <li><a href="#trainers">Trainers</a></li>
              <li><a href="#community">Community</a></li>
            </ul>
          </div>
          <div className="footer-section">
            <h4>Support</h4>
            <ul>
              <li><a href="#help">Help Center</a></li>
              <li><a href="#contact">Contact Us</a></li>
              <li><a href="#faq">FAQ</a></li>
            </ul>
          </div>
        </div>
        <div className="footer-bottom">
          <p>&copy; 2024 Obsidian Fit. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default Home;