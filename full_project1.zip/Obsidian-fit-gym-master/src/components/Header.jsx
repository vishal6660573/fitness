import { useState, useEffect } from 'react'; 
import { Link, useNavigate } from 'react-router-dom'; 
import { apiUtils } from '../services/api.js';
import './Header.css';

function Header(){
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userData, setUserData] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    // Check authentication status on component mount
    const checkAuthStatus = () => {
      const authenticated = apiUtils.isAuthenticated();
      const user = apiUtils.getUserData();
      setIsAuthenticated(authenticated);
      setUserData(user);
    };

    checkAuthStatus();
    
    // Listen for storage changes (when user logs in/out in another tab)
    const handleStorageChange = () => {
      checkAuthStatus();
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  const handleLogout = () => {
    apiUtils.clearAuth();
    setIsAuthenticated(false);
    setUserData(null);
    navigate('/login');
  };

  return (
    <header className="header-container">
      <div className="bg-light py-4 w-100 mt-3 me-2">
        <div className="container-fluid">
          <div className="header-content">
            {/* Logo/Brand Section */}
            <div className="brand-section">
              <Link to="" className="brand-link">
                <div className="logo">
                  <span className="logo-text">FitHub</span>
                  <span className="logo-subtitle">Fitness Revolution</span>
                </div>
              </Link>
            </div>

            {/* Navigation Menu */}
            <nav className="navigation-menu">
              <ul className="nav justify-content-end fs-4">
                <li className="nav-item">
                  <Link className="nav-link text-dark enhanced-link" to="" >
                    <span className="link-text">Home</span>
                    <span className="link-icon">🏠</span>
                  </Link>
                </li>
                
                {isAuthenticated && (
                  <li className="nav-item">
                    <Link className="nav-link text-dark enhanced-link" to="exercises" >
                      <span className="link-text">Exercises</span>
                      <span className="link-icon">💪</span>
                    </Link>
                  </li>
                )}
                
                <li className="nav-item">
                  <Link className="nav-link text-dark enhanced-link" to="register" >
                    <span className="link-text">Register</span>
                    <span className="link-icon">📝</span>
                  </Link>
                </li>
                
                {!isAuthenticated ? (
                  <li className="nav-item">
                    <Link className="nav-link text-dark enhanced-link login-btn" to="login" >
                      <span className="link-text">Login</span>
                      <span className="link-icon">🔐</span>
                    </Link>
                  </li>
                ) : (
                  <li className="nav-item">
                    <button 
                      className="nav-link text-dark enhanced-link logout-btn" 
                      onClick={handleLogout}
                      style={{ background: 'none', border: 'none', cursor: 'pointer' }}
                    >
                      <span className="link-text">Logout</span>
                      <span className="link-icon">🚪</span>
                    </button>
                  </li>
                )}
                
                <li className="nav-item">
                  <Link className="nav-link text-dark enhanced-link" to="technologies" >
                    <span className="link-text">Categories</span>
                    <span className="link-icon">📋</span>
                  </Link>
                </li>
              </ul>
            </nav>

            {/* Mobile Menu Toggle */}
            <div className="mobile-menu-toggle">
              <button className="menu-btn" onClick={() => {
                const nav = document.querySelector('.navigation-menu');
                nav.classList.toggle('mobile-open');
              }}>
                <span className="menu-line"></span>
                <span className="menu-line"></span>
                <span className="menu-line"></span>
              </button>
            </div>
          </div>
        </div>

        {/* User Status Indicator */}
        <div className="user-status-indicator">
          <div className={`status-dot ${isAuthenticated ? 'logged-in' : 'logged-out'}`}></div>
          <span className="status-text">
            {isAuthenticated ? `Welcome, ${userData?.username || 'User'}!` : 'Guest User'}
          </span>
        </div>
      </div>
    </header>
  )
}

export default Header;