import React from 'react'
import './Footer.css'

function Footer() {
  return (
    <footer className="footer-container">
      <div className='col'>
        <div className="aam">
          <h3 id="num">
            Top fitness brands trust <span id="ud">FitHub</span> to empower their teams and members.
          </h3>
        </div>
        
        <hr width="100%" color="#dcdcdc" size="2" />
        
        <div id="hor">
          <div className="footer-column">
            <h4 className="column-title">Get Started</h4>
            <ul className="hor">
              <li className="horiz"><a className="hori" href="#">Fitness Programs</a></li>
              <li className="horiz"><a className="hori" href="#">Join FitHub</a></li>
              <li className="horiz"><a className="hori" href="#">Download the App</a></li>
              <li className="horiz"><a className="hori" href="#">About Us</a></li>
              <li className="horiz"><a className="hori" href="#">Contact Us</a></li>
            </ul>
          </div>
          
          <div className="footer-column">
            <h4 className="column-title">Community</h4>
            <ul className="hor">
              <li className="horiz"><a className="hori" href="#">Careers</a></li>
              <li className="horiz"><a className="hori" href="#">Blog</a></li>
              <li className="horiz"><a className="hori" href="#">Help & Support</a></li>
              <li className="horiz"><a className="hori" href="#">Affiliate Program</a></li>
              <li className="horiz"><a className="hori" href="#">Investors</a></li>
            </ul>
          </div>
          
          <div className="footer-column">
            <h4 className="column-title">Legal</h4>
            <ul className="hor">
              <li className="horiz"><a className="hori" href="#">Terms & Conditions</a></li>
              <li className="horiz"><a className="hori" href="#">Privacy Policy</a></li>
              <li className="horiz"><a className="hori" href="#">Cookie Settings</a></li>
              <li className="horiz"><a className="hori" href="#">Sitemap</a></li>
              <li className="horiz"><a className="hori" href="#">Accessibility</a></li>
            </ul>
          </div>
          
          <div className="footer-column social-column">
            <h4 className="column-title">Follow Us</h4>
            <div className="social-links">
              <a href="#" className="social-link">
                <div className="social-icon facebook">f</div>
              </a>
              <a href="#" className="social-link">
                <div className="social-icon twitter">t</div>
              </a>
              <a href="#" className="social-link">
                <div className="social-icon instagram">i</div>
              </a>
              <a href="#" className="social-link">
                <div className="social-icon youtube">y</div>
              </a>
            </div>
            <div className="newsletter-signup">
              <h5>Stay Updated</h5>
              <div className="newsletter-form">
                <input type="email" placeholder="Enter your email" className="newsletter-input" />
                <button className="newsletter-btn">Subscribe</button>
              </div>
            </div>
          </div>
        </div>
        
        <div className="footer-bottom">
          <div className="footer-bottom-content">
            <p className="copyright">© 2025 FitHub. All rights reserved.</p>
            <div className="footer-badges">
              <span className="badge">🏆 Best Fitness App 2024</span>
              <span className="badge">⭐ 4.8/5 Rating</span>
              <span className="badge">👥 1M+ Users</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer