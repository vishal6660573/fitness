import React, { useState, useEffect } from 'react';

function Test2({ counter, handleCounter, title = "Child Component" }) {
  const [username, setUsername] = useState('masters Coding');
  const [isAnimating, setIsAnimating] = useState(false);
  const [usernameHistory, setUsernameHistory] = useState(['masters Coding']);

  // Predefined username options for cycling
  const usernameOptions = [
    'masters Coding',
    'full-stack-mastery',
    'react-developer',
    'javascript-ninja',
    'web-wizard',
    'code-craftsman'
  ];

  // Handle username change with animation
  const handleUsernameChange = () => {
    setIsAnimating(true);
    
    // Get next username in cycle
    const currentIndex = usernameOptions.indexOf(username);
    const nextIndex = (currentIndex + 1) % usernameOptions.length;
    const newUsername = usernameOptions[nextIndex];
    
    // Simulate loading/transition effect
    setTimeout(() => {
      setUsername(newUsername);
      setUsernameHistory(prev => [...prev, newUsername]);
      setIsAnimating(false);
    }, 300);
  };

  // Reset username to first option
  const resetUsername = () => {
    setUsername(usernameOptions[0]);
    setUsernameHistory([usernameOptions[0]]);
  };

  // Clear history
  const clearHistory = () => {
    setUsernameHistory([username]);
  };

  // Animation effect for counter changes
  useEffect(() => {
    // Could add counter change animations here
  }, [counter]);

  return (
    <div className="bg-gradient-to-r from-blue-50 to-indigo-100 p-8 mt-6 rounded-xl shadow-lg border border-blue-200 transition-all duration-300 hover:shadow-xl">
      {/* Header Section */}
      <div className="text-center mb-6">
        <h1 className="text-4xl font-bold text-blue-800 mb-2 tracking-wide">
          {title}
        </h1>
        <div className="w-24 h-1 bg-blue-500 mx-auto rounded-full"></div>
      </div>

      {/* Counter Section */}
      <div className="bg-white rounded-lg p-6 mb-6 shadow-md">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-600 mb-1">Data from Parent:</p>
            <p className="text-3xl font-bold text-indigo-600 font-mono">
              {counter}
            </p>
          </div>
          <button 
            className="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-3 px-6 rounded-lg transition-colors duration-200 transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
            onClick={handleCounter}
          >
            Increment Counter
          </button>
        </div>
      </div>

      {/* Username Section */}
      <div className="bg-white rounded-lg p-6 shadow-md">
        <div className="mb-4">
          <p className="text-sm text-gray-600 mb-2">Current Username:</p>
          <div className="flex items-center gap-3">
            <p className={`text-2xl font-semibold text-gray-800 transition-all duration-300 ${
              isAnimating ? 'opacity-50 scale-95' : 'opacity-100 scale-100'
            }`}>
              {isAnimating ? 'Changing...' : username}
            </p>
            {isAnimating && (
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-indigo-600"></div>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap gap-3 mb-4">
          <button 
            className="bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded-lg transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
            onClick={handleUsernameChange}
            disabled={isAnimating}
          >
            Change Username
          </button>
          <button 
            className="bg-green-500 hover:bg-green-600 text-white font-medium py-2 px-4 rounded-lg transition-colors duration-200"
            onClick={resetUsername}
          >
            Reset
          </button>
          <button 
            className="bg-red-500 hover:bg-red-600 text-white font-medium py-2 px-4 rounded-lg transition-colors duration-200"
            onClick={clearHistory}
          >
            Clear History
          </button>
        </div>

        {/* Username History */}
        {usernameHistory.length > 1 && (
          <div className="mt-4 p-4 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-600 mb-2">Username History:</p>
            <div className="flex flex-wrap gap-2">
              {usernameHistory.map((name, index) => (
                <span 
                  key={`${name}-${index}`}
                  className={`px-3 py-1 rounded-full text-sm font-medium ${
                    name === username 
                      ? 'bg-indigo-100 text-indigo-800 border-2 border-indigo-300' 
                      : 'bg-gray-200 text-gray-700'
                  }`}
                >
                  {name}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Stats Section */}
      <div className="mt-6 grid grid-cols-2 gap-4">
        <div className="bg-white p-4 rounded-lg shadow-md text-center">
          <p className="text-2xl font-bold text-purple-600">{usernameHistory.length}</p>
          <p className="text-sm text-gray-600">Names Used</p>
        </div>
        <div className="bg-white p-4 rounded-lg shadow-md text-center">
          <p className="text-2xl font-bold text-green-600">{counter}</p>
          <p className="text-sm text-gray-600">Counter Value</p>
        </div>
      </div>
    </div>
  );
}

export default Test2;