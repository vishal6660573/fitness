import React, { useState, useEffect } from 'react';
import { Code, Zap, Users, Rocket, Star, ArrowRight, Play, BookOpen } from 'lucide-react';

function Vue() {
  const [isVisible, setIsVisible] = useState(false);
  const [activeFeature, setActiveFeature] = useState(0);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const features = [
    {
      icon: <Zap className="w-8 h-8" />,
      title: "Progressive Framework",
      description: "Vue.js can be adopted incrementally, perfect for both small projects and large-scale applications."
    },
    {
      icon: <Code className="w-8 h-8" />,
      title: "Component-Based",
      description: "Build encapsulated components that manage their own state and compose them to create complex UIs."
    },
    {
      icon: <Rocket className="w-8 h-8" />,
      title: "High Performance",
      description: "Virtual DOM and optimized rendering system ensure your applications run smoothly and efficiently."
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: "Great Community",
      description: "Thriving ecosystem with excellent documentation, tools, and community support."
    }
  ];

  const stats = [
    { number: "3.5M+", label: "GitHub Stars", color: "text-green-600" },
    { number: "200K+", label: "Weekly Downloads", color: "text-blue-600" },
    { number: "1.8M+", label: "Developers", color: "text-purple-600" },
    { number: "40K+", label: "Companies Using", color: "text-orange-600" }
  ];

  const codeExample = `// Vue 3 Composition API Example
<template>
  <div class="counter">
    <h2>{{ count }}</h2>
    <button @click="increment">+</button>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const count = ref(0)
const increment = () => count.value++
</script>`;

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50">
      {/* Hero Section */}
      <div className={`max-w-6xl mx-auto px-6 py-16 transition-all duration-1000 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
      }`}>
        
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="w-16 h-16 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-2xl flex items-center justify-center shadow-lg">
              <span className="text-white font-bold text-2xl">V</span>
            </div>
            <h1 className="text-6xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
              Vue.js
            </h1>
          </div>
          
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
            The Progressive JavaScript Framework for building user interfaces. 
            Vue.js combines the best of React and Angular while maintaining simplicity and flexibility.
          </p>
          
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <button className="bg-gradient-to-r from-emerald-500 to-teal-500 text-white px-8 py-3 rounded-lg font-semibold hover:from-emerald-600 hover:to-teal-600 transition-all duration-200 flex items-center gap-2 shadow-lg transform hover:scale-105">
              <Play className="w-5 h-5" />
              Get Started
            </button>
            <button className="bg-white text-emerald-600 px-8 py-3 rounded-lg font-semibold border-2 border-emerald-200 hover:border-emerald-300 transition-all duration-200 flex items-center gap-2 shadow-md">
              <BookOpen className="w-5 h-5" />
              Documentation
            </button>
          </div>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white rounded-xl p-6 text-center shadow-lg hover:shadow-xl transition-shadow duration-300">
              <div className={`text-3xl font-bold ${stat.color} mb-2`}>
                {stat.number}
              </div>
              <div className="text-gray-600 font-medium">
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        {/* Features Section */}
        <div className="mb-16">
          <h2 className="text-4xl font-bold text-center text-gray-800 mb-4">
            Why Choose Vue.js?
          </h2>
          <p className="text-center text-gray-600 mb-12 max-w-2xl mx-auto">
            Vue.js offers an exceptional developer experience with its intuitive API, 
            powerful features, and gentle learning curve.
          </p>
          
          <div className="grid md:grid-cols-2 gap-8">
            {features.map((feature, index) => (
              <div 
                key={index}
                className={`bg-white rounded-xl p-8 shadow-lg cursor-pointer transition-all duration-300 hover:shadow-xl ${
                  activeFeature === index ? 'ring-2 ring-emerald-400 transform scale-105' : ''
                }`}
                onClick={() => setActiveFeature(index)}
              >
                <div className={`inline-flex p-3 rounded-lg mb-4 ${
                  activeFeature === index 
                    ? 'bg-emerald-100 text-emerald-600' 
                    : 'bg-gray-100 text-gray-600'
                }`}>
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-3">
                  {feature.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Code Example Section */}
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden mb-16">
          <div className="bg-gradient-to-r from-emerald-600 to-teal-600 px-8 py-4">
            <h3 className="text-xl font-bold text-white flex items-center gap-2">
              <Code className="w-6 h-6" />
              Vue 3 Composition API
            </h3>
          </div>
          <div className="p-8">
            <pre className="bg-gray-900 text-gray-100 p-6 rounded-lg overflow-x-auto">
              <code className="text-sm font-mono leading-relaxed">
                {codeExample}
              </code>
            </pre>
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center bg-gradient-to-r from-emerald-600 to-teal-600 rounded-2xl p-12 text-white">
          <h2 className="text-3xl font-bold mb-4">Ready to Start Building?</h2>
          <p className="text-xl mb-8 opacity-90">
            Join millions of developers who trust Vue.js for their next project
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <button className="bg-white text-emerald-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-all duration-200 flex items-center gap-2 shadow-lg">
              <Star className="w-5 h-5" />
              Star on GitHub
            </button>
            <button className="bg-emerald-700 text-white px-8 py-3 rounded-lg font-semibold hover:bg-emerald-800 transition-all duration-200 flex items-center gap-2 shadow-lg">
              Learn More
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-16 text-gray-500">
          <p>© 2024 Vue.js - The Progressive JavaScript Framework</p>
        </div>
      </div>
    </div>
  );
}

export default Vue;