 import { useForm } from "react-hook-form";
import { useNavigate, useLocation } from "react-router-dom";
import { useState, useEffect } from "react";
import { authAPI, apiUtils } from "../services/api.js";
import "./Login.css";

function Login() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const [loginError, setLoginError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  // Get the intended destination from location state
  const from = location.state?.from?.pathname || '/';

  // Check if user is already logged in
  useEffect(() => {
    if (apiUtils.isAuthenticated()) {
      const userData = apiUtils.getUserData();
      if (userData) {
        navigate(from);
      }
    }
  }, [navigate, from]);

  const handleUserLogin = async (data) => {
    setIsLoading(true);
    setLoginError(null);

    try {
      const response = await authAPI.login({
        username: data.username,
        password: data.password,
      });

      if (response.success) {
        // Redirect to the intended destination or user profile
        const userData = apiUtils.getUserData();
        if (from === '/') {
          navigate(`/user-profile/${userData.username}`);
        } else {
          navigate(from);
        }
      }
    } catch (error) {
      setLoginError({
        message: error.message || 'Login failed. Please try again.'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="login-wrapper">
      <div className="login-background">
        <div className="floating-elements">
          <div className="element element-1"></div>
          <div className="element element-2"></div>
          <div className="element element-3"></div>
          <div className="element element-4"></div>
        </div>
      </div>
      
      <div className="login-container">
        <div className="login-card">
          <div className="login-header">
            <div className="brand-logo">
              <svg width="80" height="80" viewBox="0 0 80 80" className="logo-icon">
                <defs>
                  <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#667eea" />
                    <stop offset="100%" stopColor="#764ba2" />
                  </linearGradient>
                </defs>
                <circle cx="40" cy="40" r="35" fill="url(#logoGradient)" />
                <text x="40" y="50" textAnchor="middle" fontSize="28" fill="white" fontWeight="bold">F</text>
              </svg>
            </div>
            <h1 className="brand-title">FitHub</h1>
            <p className="brand-description">Transform your fitness journey</p>
          </div>

          {loginError && (
            <div className="error-alert">
              <div className="error-content">
                <svg className="error-icon" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                </svg>
                <span className="error-text">{loginError.message}</span>
              </div>
            </div>
          )}

          <div className="login-form-section">
            <form className="login-form" onSubmit={handleSubmit(handleUserLogin)}>
              <div className="form-fields">
                <div className="input-group">
                  <label className="input-label">Username</label>
                  <div className="input-wrapper">
                    <div className="input-icon">
                      <svg fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                      </svg>
                    </div>
                    <input
                      type="text"
                      {...register("username", { required: "Username is required" })}
                      className="form-input"
                      placeholder="Enter your username"
                    />
                  </div>
                  {errors.username && (
                    <span className="field-error">{errors.username.message}</span>
                  )}
                </div>

                <div className="input-group">
                  <label className="input-label">Password</label>
                  <div className="input-wrapper">
                    <div className="input-icon">
                      <svg fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                      </svg>
                    </div>
                    <input
                      type="password"
                      {...register("password", { required: "Password is required" })}
                      className="form-input"
                      placeholder="Enter your password"
                    />
                  </div>
                  {errors.password && (
                    <span className="field-error">{errors.password.message}</span>
                  )}
                </div>
              </div>

              <div className="form-actions">
                <button 
                  type="submit" 
                  className="login-btn"
                  disabled={isLoading}
                >
                  <span>{isLoading ? 'Signing In...' : 'Sign In'}</span>
                  {!isLoading && (
                    <svg className="btn-icon" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                    </svg>
                  )}
                </button>
              </div>

              <div className="form-footer">
                <div className="footer-links">
                  <a href="#" className="link">Forgot password?</a>
                  <span className="divider">•</span>
                  <a href="/register" className="link">Create account</a>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>

      {isLoading && (
        <div className="loading-overlay active">
          <div className="loading-modal">
            <div className="spinner">
              <div></div>
              <div></div>
              <div></div>
              <div></div>
            </div>
            <p className="loading-message">Authenticating...</p>
          </div>
        </div>
      )}
    </div>
  );
}

export default Login;  