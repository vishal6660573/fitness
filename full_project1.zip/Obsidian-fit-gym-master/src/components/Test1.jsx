import React, { useState, useEffect } from 'react';
import Test2 from './Test2';
import './Test1.css';

function Test1() {
  const [counter, setCounter] = useState(100);
  const [isAnimating, setIsAnimating] = useState(false);
  const [history, setHistory] = useState([100]);
  const [theme, setTheme] = useState('light');

  // Handle counter increment
  function handleIncrement() {
    setCounter(prevCounter => {
      const newValue = prevCounter + 1;
      setHistory(prev => [...prev, newValue]);
      triggerAnimation();
      return newValue;
    });
  }

  // Handle counter decrement
  function handleDecrement() {
    setCounter(prevCounter => {
      const newValue = prevCounter - 1;
      setHistory(prev => [...prev, newValue]);
      triggerAnimation();
      return newValue;
    });
  }

  // Reset counter to initial value
  function handleReset() {
    setCounter(100);
    setHistory([100]);
    triggerAnimation();
  }

  // Set random counter value
  function handleRandom() {
    const randomValue = Math.floor(Math.random() * 1000) + 1;
    setCounter(randomValue);
    setHistory(prev => [...prev, randomValue]);
    triggerAnimation();
  }

  // Trigger animation effect
  function triggerAnimation() {
    setIsAnimating(true);
    setTimeout(() => setIsAnimating(false), 300);
  }

  // Toggle theme
  function toggleTheme() {
    setTheme(prevTheme => prevTheme === 'light' ? 'dark' : 'light');
  }

  // Get counter status
  function getCounterStatus() {
    if (counter === 100) return 'initial';
    if (counter < 100) return 'below';
    if (counter > 100) return 'above';
  }

  // Get counter color based on value
  function getCounterColor() {
    if (counter < 50) return 'danger';
    if (counter < 100) return 'warning';
    if (counter === 100) return 'success';
    if (counter < 200) return 'info';
    return 'primary';
  }

  return (
    <div className={`test-container ${theme}`}>
      <div className="test-card">
        {/* Header Section */}
        <div className="test-header">
          <h1 className="test-title">
            <span className="title-icon">🚀</span>
            Enhanced Parent Component
          </h1>
          <button 
            className="theme-toggle"
            onClick={toggleTheme}
            title={`Switch to ${theme === 'light' ? 'dark' : 'light'} theme`}
          >
            {theme === 'light' ? '🌙' : '☀️'}
          </button>
        </div>

        {/* Counter Display */}
        <div className="counter-section">
          <div className={`counter-display ${isAnimating ? 'animate' : ''}`}>
            <span className="counter-label">Current Count:</span>
            <span className={`counter-value text-${getCounterColor()}`}>
              {counter}
            </span>
          </div>
          
          <div className="counter-info">
            <div className={`status-badge status-${getCounterStatus()}`}>
              Status: {getCounterStatus().toUpperCase()}
            </div>
            <div className="history-info">
              Total Changes: {history.length - 1}
            </div>
          </div>
        </div>

        {/* Control Buttons */}
        <div className="controls-section">
          <div className="button-group">
            <button 
              className="control-btn decrement"
              onClick={handleDecrement}
              title="Decrease by 1"
            >
              <span className="btn-icon">−</span>
              <span className="btn-text">Decrease</span>
            </button>
            
            <button 
              className="control-btn increment"
              onClick={handleIncrement}
              title="Increase by 1"
            >
              <span className="btn-icon">+</span>
              <span className="btn-text">Increase</span>
            </button>
          </div>

          <div className="button-group">
            <button 
              className="control-btn reset"
              onClick={handleReset}
              title="Reset to 100"
            >
              <span className="btn-icon">🔄</span>
              <span className="btn-text">Reset</span>
            </button>
            
            <button 
              className="control-btn random"
              onClick={handleRandom}
              title="Set random value"
            >
              <span className="btn-icon">🎲</span>
              <span className="btn-text">Random</span>
            </button>
          </div>
        </div>

        {/* Statistics Section */}
        <div className="stats-section">
          <div className="stat-item">
            <span className="stat-label">Min Value:</span>
            <span className="stat-value">{Math.min(...history)}</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">Max Value:</span>
            <span className="stat-value">{Math.max(...history)}</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">Average:</span>
            <span className="stat-value">
              {(history.reduce((a, b) => a + b, 0) / history.length).toFixed(1)}
            </span>
          </div>
        </div>

        {/* Child Component */}
        <Test2 
          counter={counter} 
          handleIncrement={handleIncrement}
          handleDecrement={handleDecrement}
          handleReset={handleReset}
          handleRandom={handleRandom}
          theme={theme}
          history={history}
        />
      </div>
    </div>
  );
}

export default Test1;