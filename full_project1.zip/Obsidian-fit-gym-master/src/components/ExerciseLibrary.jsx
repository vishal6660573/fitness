import { useState, useEffect } from 'react';
import { exercisesAPI } from '../services/api.js';
import './ExerciseLibrary.css';

function ExerciseLibrary() {
  const [exercises, setExercises] = useState([]);
  const [categories, setCategories] = useState([]);
  const [muscleGroups, setMuscleGroups] = useState([]);
  const [difficultyLevels, setDifficultyLevels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filters, setFilters] = useState({
    category: '',
    difficulty: '',
    muscleGroup: '',
    search: ''
  });

  useEffect(() => {
    loadExerciseData();
  }, []);

  const loadExerciseData = async () => {
    try {
      setLoading(true);
      
      // Load exercises and metadata in parallel
      const [exercisesRes, categoriesRes, muscleGroupsRes, difficultyRes] = await Promise.all([
        exercisesAPI.getExercises(),
        exercisesAPI.getCategories(),
        exercisesAPI.getMuscleGroups(),
        exercisesAPI.getDifficultyLevels()
      ]);

      if (exercisesRes.success) {
        setExercises(exercisesRes.data.exercises);
      }
      
      if (categoriesRes.success) {
        setCategories(categoriesRes.data);
      }
      
      if (muscleGroupsRes.success) {
        setMuscleGroups(muscleGroupsRes.data);
      }
      
      if (difficultyRes.success) {
        setDifficultyLevels(difficultyRes.data);
      }
    } catch (err) {
      setError('Failed to load exercises. Please try again.');
      console.error('Error loading exercises:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (filterType, value) => {
    setFilters(prev => ({
      ...prev,
      [filterType]: value
    }));
  };

  const filteredExercises = exercises.filter(exercise => {
    const matchesCategory = !filters.category || exercise.category === filters.category;
    const matchesDifficulty = !filters.difficulty || exercise.difficulty === filters.difficulty;
    const matchesMuscleGroup = !filters.muscleGroup || exercise.muscleGroups.includes(filters.muscleGroup);
    const matchesSearch = !filters.search || 
      exercise.name.toLowerCase().includes(filters.search.toLowerCase()) ||
      exercise.instructions.toLowerCase().includes(filters.search.toLowerCase());
    
    return matchesCategory && matchesDifficulty && matchesMuscleGroup && matchesSearch;
  });

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'beginner': return '#10b981';
      case 'intermediate': return '#f59e0b';
      case 'advanced': return '#ef4444';
      default: return '#6b7280';
    }
  };

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'strength': return '💪';
      case 'cardio': return '🏃';
      case 'bodyweight': return '🤸';
      case 'flexibility': return '🧘';
      case 'sports': return '⚽';
      default: return '🏋️';
    }
  };

  if (loading) {
    return (
      <div className="exercise-library">
        <div className="loading-container">
          <div className="loading-spinner"></div>
          <p>Loading exercises...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="exercise-library">
        <div className="error-container">
          <p className="error-message">{error}</p>
          <button onClick={loadExerciseData} className="retry-button">
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="exercise-library">
      <div className="library-header">
        <h1>Exercise Library</h1>
        <p>Discover and explore exercises for your fitness journey</p>
      </div>

      {/* Filters */}
      <div className="filters-section">
        <div className="filters-grid">
          <div className="filter-group">
            <label>Search</label>
            <input
              type="text"
              placeholder="Search exercises..."
              value={filters.search}
              onChange={(e) => handleFilterChange('search', e.target.value)}
              className="filter-input"
            />
          </div>

          <div className="filter-group">
            <label>Category</label>
            <select
              value={filters.category}
              onChange={(e) => handleFilterChange('category', e.target.value)}
              className="filter-select"
            >
              <option value="">All Categories</option>
              {categories.map(category => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
          </div>

          <div className="filter-group">
            <label>Difficulty</label>
            <select
              value={filters.difficulty}
              onChange={(e) => handleFilterChange('difficulty', e.target.value)}
              className="filter-select"
            >
              <option value="">All Levels</option>
              {difficultyLevels.map(level => (
                <option key={level.id} value={level.id}>
                  {level.name}
                </option>
              ))}
            </select>
          </div>

          <div className="filter-group">
            <label>Muscle Group</label>
            <select
              value={filters.muscleGroup}
              onChange={(e) => handleFilterChange('muscleGroup', e.target.value)}
              className="filter-select"
            >
              <option value="">All Muscle Groups</option>
              {muscleGroups.map(group => (
                <option key={group.id} value={group.id}>
                  {group.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        <button
          onClick={() => setFilters({
            category: '',
            difficulty: '',
            muscleGroup: '',
            search: ''
          })}
          className="clear-filters-btn"
        >
          Clear Filters
        </button>
      </div>

      {/* Exercise Grid */}
      <div className="exercises-grid">
        {filteredExercises.length === 0 ? (
          <div className="no-results">
            <p>No exercises found matching your criteria.</p>
            <button onClick={() => setFilters({
              category: '',
              difficulty: '',
              muscleGroup: '',
              search: ''
            })} className="clear-filters-btn">
              Clear Filters
            </button>
          </div>
        ) : (
          filteredExercises.map(exercise => (
            <div key={exercise.id} className="exercise-card">
              <div className="exercise-header">
                <div className="exercise-icon">
                  {getCategoryIcon(exercise.category)}
                </div>
                <div className="exercise-info">
                  <h3 className="exercise-name">{exercise.name}</h3>
                  <div className="exercise-meta">
                    <span className="exercise-category">{exercise.category}</span>
                    <span 
                      className="exercise-difficulty"
                      style={{ backgroundColor: getDifficultyColor(exercise.difficulty) }}
                    >
                      {exercise.difficulty}
                    </span>
                  </div>
                </div>
              </div>

              <div className="exercise-details">
                <div className="muscle-groups">
                  <strong>Muscle Groups:</strong>
                  <div className="muscle-tags">
                    {exercise.muscleGroups.map(group => (
                      <span key={group} className="muscle-tag">{group}</span>
                    ))}
                  </div>
                </div>

                {exercise.instructions && (
                  <div className="exercise-instructions">
                    <strong>Instructions:</strong>
                    <p>{exercise.instructions}</p>
                  </div>
                )}

                <div className="exercise-equipment">
                  <strong>Equipment:</strong> {exercise.equipment}
                </div>
              </div>

              <div className="exercise-actions">
                <button className="add-to-workout-btn">
                  Add to Workout
                </button>
                <button className="view-details-btn">
                  View Details
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      <div className="results-summary">
        <p>Showing {filteredExercises.length} of {exercises.length} exercises</p>
      </div>
    </div>
  );
}

export default ExerciseLibrary; 