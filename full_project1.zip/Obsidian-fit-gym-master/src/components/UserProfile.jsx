import React, { useContext, useState, useEffect } from "react";
import { loginContextObj } from "../contexts/LoginContext";
import { useForm } from "react-hook-form";
import { 
  User, 
  Edit3, 
  Save, 
  X, 
  Mail, 
  Calendar, 
  Check, 
  AlertCircle,
  Loader2
} from "lucide-react";

function UserProfile() {
  const { currentUser, setCurrentUser } = useContext(loginContextObj);
  const [userEditStatus, setUserEditStatus] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [saveStatus, setSaveStatus] = useState(null);
  const [errorMessage, setErrorMessage] = useState('');

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors, isDirty },
    reset,
    watch,
    clearErrors
  } = useForm({
    defaultValues: {
      username: currentUser?.username || '',
      email: currentUser?.email || '',
      dob: currentUser?.dob || ''
    }
  });

  // Update form when currentUser changes
  useEffect(() => {
    if (currentUser) {
      reset({
        username: currentUser.username || '',
        email: currentUser.email || '',
        dob: currentUser.dob || ''
      });
    }
  }, [currentUser, reset]);

  function onUserProfileEdit() {
    setUserEditStatus(true);
    setSaveStatus(null);
    setErrorMessage('');
    clearErrors();
  }

  function onCancelEdit() {
    setUserEditStatus(false);
    setSaveStatus(null);
    setErrorMessage('');
    // Reset to current user data
    reset({
      username: currentUser.username,
      email: currentUser.email,
      dob: currentUser.dob
    });
  }

  async function onModifiedUserSave(modifiedUser) {
    setIsLoading(true);
    setSaveStatus(null);
    setErrorMessage('');
    clearErrors();

    try {
      const response = await fetch(`http://localhost:3000/users/${currentUser.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(modifiedUser)
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to update profile');
      }

      const editedUser = await response.json();
      setCurrentUser(editedUser);
      setUserEditStatus(false);
      setSaveStatus('success');
      
      setTimeout(() => setSaveStatus(null), 3000);
    } catch (error) {
      console.error("Error updating user:", error);
      setSaveStatus('error');
      setErrorMessage(error.message || 'Failed to update profile. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }

  // Format date for display
  const formatDate = (dateString) => {
    if (!dateString) return 'Not specified';
    const date = new Date(dateString);
    return isNaN(date.getTime()) 
      ? 'Invalid date' 
      : date.toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        });
  };

  // Format date for input field (YYYY-MM-DD)
  const formatDateForInput = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return isNaN(date.getTime()) 
      ? '' 
      : date.toISOString().split('T')[0];
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Header */}
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-800 mb-2">User Profile</h2>
        <div className="w-24 h-1 bg-blue-500 mx-auto rounded-full"></div>
      </div>

      {/* Success/Error Messages */}
      {saveStatus && (
        <div className={`mb-6 p-4 rounded-lg flex items-center gap-3 ${
          saveStatus === 'success' 
            ? 'bg-green-50 border border-green-200 text-green-800' 
            : 'bg-red-50 border border-red-200 text-red-800'
        }`}>
          {saveStatus === 'success' ? (
            <Check className="w-5 h-5 text-green-600" />
          ) : (
            <AlertCircle className="w-5 h-5 text-red-600" />
          )}
          <span className="font-medium">
            {saveStatus === 'success' 
              ? 'Profile updated successfully!' 
              : errorMessage
            }
          </span>
        </div>
      )}

      {!userEditStatus ? (
        /* Profile View Mode */
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          {/* Profile Header */}
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 px-8 py-12 text-center">
            <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center mx-auto mb-4">
              <User className="w-12 h-12 text-blue-600" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-2">
              {currentUser?.username || 'Unknown User'}
            </h3>
            <p className="text-blue-100">Member Profile</p>
          </div>

          {/* Profile Details */}
          <div className="p-8">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Email */}
              <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <Mail className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600 font-medium">Email Address</p>
                  <p className="text-gray-800 font-semibold">
                    {currentUser?.email || 'Not provided'}
                  </p>
                </div>
              </div>

              {/* Date of Birth */}
              <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600 font-medium">Date of Birth</p>
                  <p className="text-gray-800 font-semibold">
                    {formatDate(currentUser?.dob)}
                  </p>
                </div>
              </div>
            </div>

            {/* Edit Button */}
            <div className="mt-8 text-center">
              <button
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold py-3 px-8 rounded-lg transition-all duration-200 transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 flex items-center gap-2 mx-auto"
                onClick={onUserProfileEdit}
              >
                <Edit3 className="w-5 h-5" />
                Edit Profile
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Edit Mode */
        <div className="bg-white rounded-2xl shadow-lg p-8">
          <div className="mb-6">
            <h3 className="text-2xl font-bold text-gray-800 mb-2">Edit Profile</h3>
            <p className="text-gray-600">Update your profile information below</p>
          </div>

          <form onSubmit={handleSubmit(onModifiedUserSave)} className="space-y-6">
            {/* Username Field */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Username
              </label>
              <input
                type="text"
                value={currentUser?.username || ''}
                readOnly
                className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-100"
              />
              <p className="mt-1 text-sm text-gray-500">Username cannot be changed</p>
            </div>

            {/* Email Field */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email Address
              </label>
              <input
                type="email"
                {...register('email', {
                  required: 'Email is required',
                  pattern: {
                    value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                    message: 'Please enter a valid email address'
                  }
                })}
                className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors ${
                  errors.email 
                    ? 'border-red-300 focus:ring-red-500' 
                    : 'border-gray-300'
                }`}
                placeholder="Enter your email address"
              />
              {errors.email && (
                <p className="mt-2 text-sm text-red-600 flex items-center gap-1">
                  <AlertCircle className="w-4 h-4" />
                  {errors.email.message}
                </p>
              )}
            </div>

            {/* Date of Birth Field */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Date of Birth
              </label>
              <input
                type="date"
                {...register('dob', {
                  required: 'Date of birth is required',
                  validate: value => {
                    const date = new Date(value);
                    const today = new Date();
                    return date <= today || 'Date cannot be in the future';
                  }
                })}
                defaultValue={formatDateForInput(currentUser?.dob)}
                className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors ${
                  errors.dob 
                    ? 'border-red-300 focus:ring-red-500' 
                    : 'border-gray-300'
                }`}
                max={new Date().toISOString().split('T')[0]}
              />
              {errors.dob && (
                <p className="mt-2 text-sm text-red-600 flex items-center gap-1">
                  <AlertCircle className="w-4 h-4" />
                  {errors.dob.message}
                </p>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex gap-4 pt-6">
              <button
                type="submit"
                disabled={isLoading || !isDirty}
                className={`flex-1 py-3 px-6 rounded-lg font-semibold transition-all duration-200 flex items-center justify-center gap-2 ${
                  isLoading || !isDirty
                    ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    : 'bg-green-600 hover:bg-green-700 text-white transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2'
                }`}
              >
                {isLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Save className="w-5 h-5" />
                )}
                {isLoading ? 'Saving...' : 'Save Changes'}
              </button>

              <button
                type="button"
                onClick={onCancelEdit}
                disabled={isLoading}
                className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-700 py-3 px-6 rounded-lg font-semibold transition-all duration-200 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <X className="w-5 h-5" />
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

export default UserProfile;