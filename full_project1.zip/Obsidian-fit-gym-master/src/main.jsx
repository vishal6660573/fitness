import 'bootstrap/dist/css/bootstrap.min.css';
import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import './index.css';
import CounterContext from './contexts/CounterContext.jsx';
import LoginContext from './contexts/LoginContext.jsx';

// Enhanced root rendering with better error handling
const initializeApp = () => {
  const rootElement = document.getElementById('root');
  
  if (!rootElement) {
    console.error('Root element not found. Make sure there is a div with id="root" in your HTML.');
    return;
  }

  try {
    const root = createRoot(rootElement);
    
    root.render(
      <StrictMode>
        <CounterContext>
          <LoginContext>
            <App />
          </LoginContext>
        </CounterContext>
      </StrictMode>
    );
    
    // Log successful initialization
    console.log('App initialized successfully');
    
  } catch (error) {
    console.error('Failed to initialize app:', error);
    
    // Simple fallback rendering
    rootElement.innerHTML = `
      <div style="
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        font-family: Arial, sans-serif;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        text-align: center;
        padding: 20px;
      ">
        <div>
          <h2>Failed to load application</h2>
          <p>Please refresh the page or contact support if the problem persists.</p>
          <button 
            onclick="window.location.reload()" 
            style="
              background: white;
              color: #667eea;
              border: none;
              padding: 10px 20px;
              border-radius: 5px;
              cursor: pointer;
              font-size: 16px;
              margin-top: 20px;
            "
          >
            Reload Page
          </button>
        </div>
      </div>
    `;
  }
};

// Optional: Performance monitoring
if (typeof window !== 'undefined' && 'performance' in window) {
  window.addEventListener('load', () => {
    const perfData = performance.getEntriesByType('navigation')[0];
    if (perfData) {
      console.log('App Performance Metrics:', {
        loadTime: Math.round(perfData.loadEventEnd - perfData.loadEventStart),
        domContentLoaded: Math.round(perfData.domContentLoadedEventEnd - perfData.domContentLoadedEventStart),
        totalTime: Math.round(perfData.loadEventEnd - perfData.fetchStart)
      });
    }
  });
}

// Initialize the application
initializeApp();