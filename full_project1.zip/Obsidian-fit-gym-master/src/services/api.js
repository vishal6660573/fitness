const API_BASE_URL = 'http://localhost:5000/api';

// Helper function to get auth token from localStorage
const getAuthToken = () => {
  return localStorage.getItem('authToken');
};

// Helper function to set auth token
const setAuthToken = (token) => {
  if (token) {
    localStorage.setItem('authToken', token);
  } else {
    localStorage.removeItem('authToken');
  }
};

// Helper function to get user data
const getUserData = () => {
  const userData = localStorage.getItem('userData');
  return userData ? JSON.parse(userData) : null;
};

// Helper function to set user data
const setUserData = (userData) => {
  if (userData) {
    localStorage.setItem('userData', JSON.stringify(userData));
  } else {
    localStorage.removeItem('userData');
  }
};

// Generic API request function
const apiRequest = async (endpoint, options = {}) => {
  const token = getAuthToken();
  
  const config = {
    headers: {
      'Content-Type': 'application/json',
      ...(token && { Authorization: `Bearer ${token}` }),
      ...options.headers,
    },
    ...options,
  };

  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, config);
    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || 'API request failed');
    }

    return data;
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
};

// Authentication API
export const authAPI = {
  // Register new user
  register: async (userData) => {
    const response = await apiRequest('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
    
    if (response.success && response.data.token) {
      setAuthToken(response.data.token);
      setUserData(response.data.user);
    }
    
    return response;
  },

  // Login user
  login: async (credentials) => {
    const response = await apiRequest('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    });
    
    if (response.success && response.data.token) {
      setAuthToken(response.data.token);
      setUserData(response.data.user);
    }
    
    return response;
  },

  // Logout user
  logout: () => {
    setAuthToken(null);
    setUserData(null);
  },

  // Get current user profile
  getProfile: async () => {
    return await apiRequest('/auth/me');
  },

  // Refresh token
  refreshToken: async () => {
    const response = await apiRequest('/auth/refresh', {
      method: 'POST',
    });
    
    if (response.success && response.data.token) {
      setAuthToken(response.data.token);
    }
    
    return response;
  },

  // Change password
  changePassword: async (passwordData) => {
    return await apiRequest('/auth/change-password', {
      method: 'PUT',
      body: JSON.stringify(passwordData),
    });
  },
};

// Users API
export const usersAPI = {
  // Get user profile
  getUser: async (userId) => {
    return await apiRequest(`/users/${userId}`);
  },

  // Update user profile
  updateProfile: async (userData) => {
    return await apiRequest('/users/profile', {
      method: 'PUT',
      body: JSON.stringify(userData),
    });
  },

  // Upload profile picture
  uploadProfilePicture: async (profilePicture) => {
    return await apiRequest('/users/profile-picture', {
      method: 'POST',
      body: JSON.stringify({ profilePicture }),
    });
  },

  // Get user statistics
  getUserStats: async () => {
    return await apiRequest('/users/stats/overview');
  },
};

// Exercises API
export const exercisesAPI = {
  // Get all exercises
  getExercises: async (params = {}) => {
    const queryString = new URLSearchParams(params).toString();
    return await apiRequest(`/exercises?${queryString}`);
  },

  // Get exercise by ID
  getExercise: async (exerciseId) => {
    return await apiRequest(`/exercises/${exerciseId}`);
  },

  // Get exercise categories
  getCategories: async () => {
    return await apiRequest('/exercises/categories/list');
  },

  // Get muscle groups
  getMuscleGroups: async () => {
    return await apiRequest('/exercises/muscle-groups/list');
  },

  // Get difficulty levels
  getDifficultyLevels: async () => {
    return await apiRequest('/exercises/difficulty-levels/list');
  },
};

// Workouts API
export const workoutsAPI = {
  // Get user workouts
  getWorkouts: async (params = {}) => {
    const queryString = new URLSearchParams(params).toString();
    return await apiRequest(`/workouts?${queryString}`);
  },

  // Get workout by ID
  getWorkout: async (workoutId) => {
    return await apiRequest(`/workouts/${workoutId}`);
  },

  // Create new workout
  createWorkout: async (workoutData) => {
    return await apiRequest('/workouts', {
      method: 'POST',
      body: JSON.stringify(workoutData),
    });
  },

  // Update workout
  updateWorkout: async (workoutId, workoutData) => {
    return await apiRequest(`/workouts/${workoutId}`, {
      method: 'PUT',
      body: JSON.stringify(workoutData),
    });
  },

  // Complete workout
  completeWorkout: async (workoutId, completionData) => {
    return await apiRequest(`/workouts/${workoutId}/complete`, {
      method: 'PATCH',
      body: JSON.stringify(completionData),
    });
  },

  // Delete workout
  deleteWorkout: async (workoutId) => {
    return await apiRequest(`/workouts/${workoutId}`, {
      method: 'DELETE',
    });
  },

  // Get workout statistics
  getWorkoutStats: async () => {
    return await apiRequest('/workouts/stats/overview');
  },

  // Get workout templates
  getTemplates: async (params = {}) => {
    const queryString = new URLSearchParams(params).toString();
    return await apiRequest(`/workouts/templates?${queryString}`);
  },
};

// Nutrition API
export const nutritionAPI = {
  // Get nutrition entries
  getEntries: async (params = {}) => {
    const queryString = new URLSearchParams(params).toString();
    return await apiRequest(`/nutrition?${queryString}`);
  },

  // Get nutrition entry by ID
  getEntry: async (entryId) => {
    return await apiRequest(`/nutrition/${entryId}`);
  },

  // Create nutrition entry
  createEntry: async (entryData) => {
    return await apiRequest('/nutrition', {
      method: 'POST',
      body: JSON.stringify(entryData),
    });
  },

  // Update nutrition entry
  updateEntry: async (entryId, entryData) => {
    return await apiRequest(`/nutrition/${entryId}`, {
      method: 'PUT',
      body: JSON.stringify(entryData),
    });
  },

  // Delete nutrition entry
  deleteEntry: async (entryId) => {
    return await apiRequest(`/nutrition/${entryId}`, {
      method: 'DELETE',
    });
  },

  // Get nutrition statistics
  getStats: async (params = {}) => {
    const queryString = new URLSearchParams(params).toString();
    return await apiRequest(`/nutrition/stats/overview?${queryString}`);
  },

  // Get meal suggestions
  getMealSuggestions: async (params = {}) => {
    const queryString = new URLSearchParams(params).toString();
    return await apiRequest(`/nutrition/suggestions/meals?${queryString}`);
  },

  // Get nutrition goals
  getGoals: async () => {
    return await apiRequest('/nutrition/goals');
  },
};

// Progress API
export const progressAPI = {
  // Get progress entries
  getEntries: async (params = {}) => {
    const queryString = new URLSearchParams(params).toString();
    return await apiRequest(`/progress?${queryString}`);
  },

  // Get progress entry by ID
  getEntry: async (entryId) => {
    return await apiRequest(`/progress/${entryId}`);
  },

  // Create progress entry
  createEntry: async (entryData) => {
    return await apiRequest('/progress', {
      method: 'POST',
      body: JSON.stringify(entryData),
    });
  },

  // Update progress entry
  updateEntry: async (entryId, entryData) => {
    return await apiRequest(`/progress/${entryId}`, {
      method: 'PUT',
      body: JSON.stringify(entryData),
    });
  },

  // Delete progress entry
  deleteEntry: async (entryId) => {
    return await apiRequest(`/progress/${entryId}`, {
      method: 'DELETE',
    });
  },

  // Get progress statistics
  getStats: async (params = {}) => {
    const queryString = new URLSearchParams(params).toString();
    return await apiRequest(`/progress/stats/overview?${queryString}`);
  },

  // Get progress goals
  getGoals: async () => {
    return await apiRequest('/progress/goals');
  },

  // Get measurement types
  getMeasurementTypes: async () => {
    return await apiRequest('/progress/measurement-types');
  },
};

// Utility functions
export const apiUtils = {
  getAuthToken,
  setAuthToken,
  getUserData,
  setUserData,
  isAuthenticated: () => !!getAuthToken(),
  clearAuth: () => {
    setAuthToken(null);
    setUserData(null);
  },
};

export default {
  auth: authAPI,
  users: usersAPI,
  exercises: exercisesAPI,
  workouts: workoutsAPI,
  nutrition: nutritionAPI,
  progress: progressAPI,
  utils: apiUtils,
}; 