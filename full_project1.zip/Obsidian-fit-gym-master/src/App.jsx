import './App.css'
import { lazy, Suspense } from 'react';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import RootLayout from './components/RootLayout';
import Home from './components/Home';
import Register from './components/Register';
import Login from './components/Login';
import UserProfile from './components/UserProfile';
import ExerciseLibrary from './components/ExerciseLibrary';
import ProtectedRoute from './components/ProtectedRoute';
import Java from './components/Java';
import Node from './components/Node';
import Vue from './components/Vue';
import RoutingError from './components/RoutingError';

// Lazy load components for better performance
const Technologies = lazy(() => import("./components/Technologies"));

// Enhanced loading component with better UX
const LoadingSpinner = () => (
  <div className="loading-container">
    <div className="spinner"></div>
    <p className="loading-text">Loading...</p>
  </div>
);

// Error boundary component for lazy loading
const LazyLoadError = ({ error, retry }) => (
  <div className="lazy-load-error">
    <h3>Something went wrong</h3>
    <p>Failed to load component. Please try again.</p>
    <button onClick={retry} className="retry-btn">
      Retry
    </button>
  </div>
);

function App() {
  // Routing configuration with improved structure
  const browserRouterObject = createBrowserRouter([
    {
      path: "/", // More explicit root path
      element: <RootLayout />,
      errorElement: <RoutingError />,
      children: [
        {
          index: true, // Use index route instead of empty path
          element: <Home />
        },
        {
          path: 'register',
          element: <Register />,
          // Add meta data for potential SEO or analytics
          handle: {
            title: 'Register',
            description: 'Create a new account'
          }
        },
        {
          path: 'login',
          element: <Login />,
          handle: {
            title: 'Login',
            description: 'Sign in to your account'
          }
        },
        {
          path: 'user-profile/:username',
          element: (
            <ProtectedRoute>
              <UserProfile />
            </ProtectedRoute>
          ),
          handle: {
            title: 'User Profile',
            description: 'View user profile'
          }
        },
        {
          path: 'exercises',
          element: (
            <ProtectedRoute>
              <ExerciseLibrary />
            </ProtectedRoute>
          ),
          handle: {
            title: 'Exercise Library',
            description: 'Browse and discover exercises'
          }
        },
        {
          path: 'technologies',
          element: (
            <Suspense fallback={<LoadingSpinner />}>
              <Technologies />
            </Suspense>
          ),
          handle: {
            title: 'Technologies',
            description: 'Explore different technologies'
          },
          children: [
            {
              index: true,
              element: (
                <div className="tech-welcome">
                  <h2>Welcome to Technologies</h2>
                  <p>Select a technology to learn more about it.</p>
                </div>
              )
            },
            {
              path: 'java',
              element: <Java />,
              handle: {
                title: 'Java',
                description: 'Learn about Java programming'
              }
            },
            {
              path: 'node',
              element: <Node />,
              handle: {
                title: 'Node.js',
                description: 'Learn about Node.js development'
              }
            },
            {
              path: 'vue',
              element: <Vue />,
              handle: {
                title: 'Vue.js',
                description: 'Learn about Vue.js framework'
              }
            }
          ]
        },
        {
          path: '*',
          element: <RoutingError />,
          handle: {
            title: '404 - Page Not Found',
            description: 'The page you are looking for does not exist'
          }
        }
      ]
    }
  ]);

  return (
    <div className="app-container clr">
      <RouterProvider 
        router={browserRouterObject}
        fallbackElement={<LoadingSpinner />}
      />
    </div>
  );
}

export default App;