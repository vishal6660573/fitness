import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Database file paths
const DB_DIR = path.join(__dirname, '..', 'data');
const USERS_FILE = path.join(DB_DIR, 'users.json');
const WORKOUTS_FILE = path.join(DB_DIR, 'workouts.json');
const EXERCISES_FILE = path.join(DB_DIR, 'exercises.json');
const NUTRITION_FILE = path.join(DB_DIR, 'nutrition.json');
const PROGRESS_FILE = path.join(DB_DIR, 'progress.json');

// Initialize database structure
const initializeDatabase = async () => {
  try {
    // Create data directory if it doesn't exist
    await fs.mkdir(DB_DIR, { recursive: true });

    // Initialize users.json if it doesn't exist
    try {
      await fs.access(USERS_FILE);
    } catch {
      await fs.writeFile(USERS_FILE, JSON.stringify([], null, 2));
    }

    // Initialize workouts.json if it doesn't exist
    try {
      await fs.access(WORKOUTS_FILE);
    } catch {
      await fs.writeFile(WORKOUTS_FILE, JSON.stringify([], null, 2));
    }

    // Initialize exercises.json if it doesn't exist
    try {
      await fs.access(EXERCISES_FILE);
    } catch {
      const defaultExercises = [
        {
          id: '1',
          name: 'Push-ups',
          category: 'bodyweight',
          muscleGroups: ['chest', 'triceps', 'shoulders'],
          difficulty: 'beginner',
          instructions: 'Start in plank position, lower body, push back up',
          equipment: 'none',
          imageUrl: null,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        },
        {
          id: '2',
          name: 'Squats',
          category: 'bodyweight',
          muscleGroups: ['legs', 'glutes'],
          difficulty: 'beginner',
          instructions: 'Stand with feet shoulder-width apart, lower hips, stand back up',
          equipment: 'none',
          imageUrl: null,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        },
        {
          id: '3',
          name: 'Pull-ups',
          category: 'bodyweight',
          muscleGroups: ['back', 'biceps'],
          difficulty: 'intermediate',
          instructions: 'Hang from bar, pull body up until chin over bar',
          equipment: 'pull-up bar',
          imageUrl: null,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        }
      ];
      await fs.writeFile(EXERCISES_FILE, JSON.stringify(defaultExercises, null, 2));
    }

    // Initialize nutrition.json if it doesn't exist
    try {
      await fs.access(NUTRITION_FILE);
    } catch {
      await fs.writeFile(NUTRITION_FILE, JSON.stringify([], null, 2));
    }

    // Initialize progress.json if it doesn't exist
    try {
      await fs.access(PROGRESS_FILE);
    } catch {
      await fs.writeFile(PROGRESS_FILE, JSON.stringify([], null, 2));
    }

    console.log('✅ Database initialized successfully');
  } catch (error) {
    console.error('❌ Database initialization failed:', error);
    throw error;
  }
};

// Database operations
const readData = async (filePath) => {
  try {
    const data = await fs.readFile(filePath, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error(`Error reading ${filePath}:`, error);
    return [];
  }
};

const writeData = async (filePath, data) => {
  try {
    await fs.writeFile(filePath, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error(`Error writing to ${filePath}:`, error);
    return false;
  }
};

// Export database functions
export {
  initializeDatabase,
  readData,
  writeData,
  USERS_FILE,
  WORKOUTS_FILE,
  EXERCISES_FILE,
  NUTRITION_FILE,
  PROGRESS_FILE,
  DB_DIR
}; 