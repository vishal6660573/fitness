import { body, validationResult } from 'express-validator';

// Common validation rules
export const validateRegistration = [
  body('username')
    .trim()
    .isLength({ min: 3, max: 30 })
    .withMessage('Username must be between 3 and 30 characters')
    .matches(/^[a-zA-Z0-9_]+$/)
    .withMessage('Username can only contain letters, numbers, and underscores'),
  
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address'),
  
  body('password')
    .isLength({ min: 6 })
    .withMessage('Password must be at least 6 characters long')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .withMessage('Password must contain at least one uppercase letter, one lowercase letter, and one number'),
  
  body('dob')
    .optional()
    .isISO8601()
    .withMessage('Date of birth must be a valid date'),
  
  body('phoneNumber')
    .optional()
    .matches(/^\+?[\d\s\-\(\)]+$/)
    .withMessage('Please provide a valid phone number'),
];

export const validateLogin = [
  body('username')
    .trim()
    .notEmpty()
    .withMessage('Username is required'),
  
  body('password')
    .notEmpty()
    .withMessage('Password is required'),
];

export const validateUserUpdate = [
  body('username')
    .optional()
    .trim()
    .isLength({ min: 3, max: 30 })
    .withMessage('Username must be between 3 and 30 characters')
    .matches(/^[a-zA-Z0-9_]+$/)
    .withMessage('Username can only contain letters, numbers, and underscores'),
  
  body('email')
    .optional()
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address'),
  
  body('dob')
    .optional()
    .isISO8601()
    .withMessage('Date of birth must be a valid date'),
  
  body('phoneNumber')
    .optional()
    .matches(/^\+?[\d\s\-\(\)]+$/)
    .withMessage('Please provide a valid phone number'),
];

export const validateWorkout = [
  body('name')
    .trim()
    .isLength({ min: 1, max: 100 })
    .withMessage('Workout name must be between 1 and 100 characters'),
  
  body('description')
    .optional()
    .trim()
    .isLength({ max: 500 })
    .withMessage('Description must be less than 500 characters'),
  
  body('exercises')
    .isArray({ min: 1 })
    .withMessage('At least one exercise is required'),
  
  body('exercises.*.exerciseId')
    .notEmpty()
    .withMessage('Exercise ID is required'),
  
  body('exercises.*.sets')
    .isInt({ min: 1 })
    .withMessage('Sets must be at least 1'),
  
  body('exercises.*.reps')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Reps must be at least 1'),
  
  body('exercises.*.weight')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Weight must be a positive number'),
  
  body('exercises.*.duration')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Duration must be at least 1 second'),
];

export const validateExercise = [
  body('name')
    .trim()
    .isLength({ min: 1, max: 100 })
    .withMessage('Exercise name must be between 1 and 100 characters'),
  
  body('category')
    .isIn(['bodyweight', 'strength', 'cardio', 'flexibility', 'sports'])
    .withMessage('Invalid exercise category'),
  
  body('muscleGroups')
    .isArray({ min: 1 })
    .withMessage('At least one muscle group is required'),
  
  body('difficulty')
    .isIn(['beginner', 'intermediate', 'advanced'])
    .withMessage('Invalid difficulty level'),
  
  body('instructions')
    .optional()
    .trim()
    .isLength({ max: 1000 })
    .withMessage('Instructions must be less than 1000 characters'),
];

export const validateNutrition = [
  body('date')
    .isISO8601()
    .withMessage('Date must be a valid date'),
  
  body('meals')
    .isArray({ min: 1 })
    .withMessage('At least one meal is required'),
  
  body('meals.*.name')
    .trim()
    .isLength({ min: 1, max: 100 })
    .withMessage('Meal name must be between 1 and 100 characters'),
  
  body('meals.*.calories')
    .isInt({ min: 0 })
    .withMessage('Calories must be a positive number'),
  
  body('meals.*.protein')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Protein must be a positive number'),
  
  body('meals.*.carbs')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Carbs must be a positive number'),
  
  body('meals.*.fat')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Fat must be a positive number'),
];

// Validation result handler
export const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: 'Validation failed',
      errors: errors.array().map(error => ({
        field: error.path,
        message: error.msg
      }))
    });
  }
  next();
}; 