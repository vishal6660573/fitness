import express from 'express';
import { v4 as uuidv4 } from 'uuid';
import { readData, writeData, WORKOUTS_FILE, EXERCISES_FILE } from '../config/database.js';
import { authenticateToken } from '../middleware/auth.js';
import { validateWorkout, handleValidationErrors } from '../utils/validation.js';

const router = express.Router();

// Get all workouts for current user
router.get('/', authenticateToken, async (req, res) => {
  try {
    const { page = 1, limit = 10, category = '', difficulty = '' } = req.query;
    const workouts = await readData(WORKOUTS_FILE);
    
    // Filter workouts by user
    let userWorkouts = workouts.filter(workout => workout.userId === req.user.id);

    // Apply filters
    if (category) {
      userWorkouts = userWorkouts.filter(workout => workout.category === category);
    }
    if (difficulty) {
      userWorkouts = userWorkouts.filter(workout => workout.difficulty === difficulty);
    }

    // Sort by creation date (newest first)
    userWorkouts.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    // Pagination
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    const paginatedWorkouts = userWorkouts.slice(startIndex, endIndex);

    res.json({
      success: true,
      data: {
        workouts: paginatedWorkouts,
        pagination: {
          currentPage: parseInt(page),
          totalPages: Math.ceil(userWorkouts.length / limit),
          totalWorkouts: userWorkouts.length,
          workoutsPerPage: parseInt(limit)
        }
      }
    });
  } catch (error) {
    console.error('Get workouts error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get workouts'
    });
  }
});

// Get workout by ID
router.get('/:workoutId', authenticateToken, async (req, res) => {
  try {
    const { workoutId } = req.params;
    const workouts = await readData(WORKOUTS_FILE);
    const workout = workouts.find(w => w.id === workoutId && w.userId === req.user.id);

    if (!workout) {
      return res.status(404).json({
        success: false,
        message: 'Workout not found'
      });
    }

    res.json({
      success: true,
      data: workout
    });
  } catch (error) {
    console.error('Get workout error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get workout'
    });
  }
});

// Create new workout
router.post('/', authenticateToken, validateWorkout, handleValidationErrors, async (req, res) => {
  try {
    const { name, description, exercises, category = 'strength', difficulty = 'beginner' } = req.body;

    // Validate exercises exist
    const exercisesData = await readData(EXERCISES_FILE);
    for (const exercise of exercises) {
      const exerciseExists = exercisesData.find(e => e.id === exercise.exerciseId);
      if (!exerciseExists) {
        return res.status(400).json({
          success: false,
          message: `Exercise with ID ${exercise.exerciseId} not found`
        });
      }
    }

    const newWorkout = {
      id: uuidv4(),
      userId: req.user.id,
      name,
      description: description || '',
      category,
      difficulty,
      exercises,
      isCompleted: false,
      completedAt: null,
      duration: null,
      notes: '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const workouts = await readData(WORKOUTS_FILE);
    workouts.push(newWorkout);
    await writeData(WORKOUTS_FILE, workouts);

    res.status(201).json({
      success: true,
      message: 'Workout created successfully',
      data: newWorkout
    });
  } catch (error) {
    console.error('Create workout error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create workout'
    });
  }
});

// Update workout
router.put('/:workoutId', authenticateToken, validateWorkout, handleValidationErrors, async (req, res) => {
  try {
    const { workoutId } = req.params;
    const { name, description, exercises, category, difficulty, notes } = req.body;

    const workouts = await readData(WORKOUTS_FILE);
    const workoutIndex = workouts.findIndex(w => w.id === workoutId && w.userId === req.user.id);

    if (workoutIndex === -1) {
      return res.status(404).json({
        success: false,
        message: 'Workout not found'
      });
    }

    // Validate exercises exist
    const exercisesData = await readData(EXERCISES_FILE);
    for (const exercise of exercises) {
      const exerciseExists = exercisesData.find(e => e.id === exercise.exerciseId);
      if (!exerciseExists) {
        return res.status(400).json({
          success: false,
          message: `Exercise with ID ${exercise.exerciseId} not found`
        });
      }
    }

    // Update workout
    const workout = workouts[workoutIndex];
    if (name) workout.name = name;
    if (description !== undefined) workout.description = description;
    if (exercises) workout.exercises = exercises;
    if (category) workout.category = category;
    if (difficulty) workout.difficulty = difficulty;
    if (notes !== undefined) workout.notes = notes;
    workout.updatedAt = new Date().toISOString();

    await writeData(WORKOUTS_FILE, workouts);

    res.json({
      success: true,
      message: 'Workout updated successfully',
      data: workout
    });
  } catch (error) {
    console.error('Update workout error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update workout'
    });
  }
});

// Complete workout
router.patch('/:workoutId/complete', authenticateToken, async (req, res) => {
  try {
    const { workoutId } = req.params;
    const { duration, notes } = req.body;

    const workouts = await readData(WORKOUTS_FILE);
    const workoutIndex = workouts.findIndex(w => w.id === workoutId && w.userId === req.user.id);

    if (workoutIndex === -1) {
      return res.status(404).json({
        success: false,
        message: 'Workout not found'
      });
    }

    // Update workout completion
    const workout = workouts[workoutIndex];
    workout.isCompleted = true;
    workout.completedAt = new Date().toISOString();
    workout.duration = duration || null;
    if (notes !== undefined) workout.notes = notes;
    workout.updatedAt = new Date().toISOString();

    await writeData(WORKOUTS_FILE, workouts);

    res.json({
      success: true,
      message: 'Workout completed successfully',
      data: workout
    });
  } catch (error) {
    console.error('Complete workout error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to complete workout'
    });
  }
});

// Delete workout
router.delete('/:workoutId', authenticateToken, async (req, res) => {
  try {
    const { workoutId } = req.params;
    const workouts = await readData(WORKOUTS_FILE);
    const workoutIndex = workouts.findIndex(w => w.id === workoutId && w.userId === req.user.id);

    if (workoutIndex === -1) {
      return res.status(404).json({
        success: false,
        message: 'Workout not found'
      });
    }

    // Remove workout
    workouts.splice(workoutIndex, 1);
    await writeData(WORKOUTS_FILE, workouts);

    res.json({
      success: true,
      message: 'Workout deleted successfully'
    });
  } catch (error) {
    console.error('Delete workout error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete workout'
    });
  }
});

// Get workout statistics
router.get('/stats/overview', authenticateToken, async (req, res) => {
  try {
    const workouts = await readData(WORKOUTS_FILE);
    const userWorkouts = workouts.filter(w => w.userId === req.user.id);

    const stats = {
      totalWorkouts: userWorkouts.length,
      completedWorkouts: userWorkouts.filter(w => w.isCompleted).length,
      pendingWorkouts: userWorkouts.filter(w => !w.isCompleted).length,
      averageDuration: userWorkouts
        .filter(w => w.duration)
        .reduce((acc, w) => acc + w.duration, 0) / 
        userWorkouts.filter(w => w.duration).length || 0,
      categoryDistribution: {
        strength: userWorkouts.filter(w => w.category === 'strength').length,
        cardio: userWorkouts.filter(w => w.category === 'cardio').length,
        flexibility: userWorkouts.filter(w => w.category === 'flexibility').length,
        sports: userWorkouts.filter(w => w.category === 'sports').length
      },
      difficultyDistribution: {
        beginner: userWorkouts.filter(w => w.difficulty === 'beginner').length,
        intermediate: userWorkouts.filter(w => w.difficulty === 'intermediate').length,
        advanced: userWorkouts.filter(w => w.difficulty === 'advanced').length
      },
      recentActivity: userWorkouts
        .filter(w => w.isCompleted)
        .sort((a, b) => new Date(b.completedAt) - new Date(a.completedAt))
        .slice(0, 5)
    };

    res.json({
      success: true,
      data: stats
    });
  } catch (error) {
    console.error('Get workout stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get workout statistics'
    });
  }
});

// Get workout templates (predefined workouts)
router.get('/templates', authenticateToken, async (req, res) => {
  try {
    const { category = '', difficulty = '' } = req.query;
    
    const templates = [
      {
        id: 'template-1',
        name: 'Full Body Strength',
        description: 'Complete full body workout for strength building',
        category: 'strength',
        difficulty: 'beginner',
        exercises: [
          { exerciseId: '1', sets: 3, reps: 10, weight: null, duration: null },
          { exerciseId: '2', sets: 3, reps: 12, weight: null, duration: null },
          { exerciseId: '3', sets: 3, reps: 8, weight: null, duration: null }
        ]
      },
      {
        id: 'template-2',
        name: 'Upper Body Focus',
        description: 'Target chest, back, and arms',
        category: 'strength',
        difficulty: 'intermediate',
        exercises: [
          { exerciseId: '1', sets: 4, reps: 12, weight: null, duration: null },
          { exerciseId: '3', sets: 4, reps: 10, weight: null, duration: null }
        ]
      },
      {
        id: 'template-3',
        name: 'Lower Body Power',
        description: 'Build leg strength and power',
        category: 'strength',
        difficulty: 'intermediate',
        exercises: [
          { exerciseId: '2', sets: 4, reps: 15, weight: null, duration: null }
        ]
      }
    ];

    let filteredTemplates = templates;
    if (category) {
      filteredTemplates = filteredTemplates.filter(t => t.category === category);
    }
    if (difficulty) {
      filteredTemplates = filteredTemplates.filter(t => t.difficulty === difficulty);
    }

    res.json({
      success: true,
      data: filteredTemplates
    });
  } catch (error) {
    console.error('Get workout templates error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get workout templates'
    });
  }
});

export default router; 