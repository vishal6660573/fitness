import express from 'express';
import { v4 as uuidv4 } from 'uuid';
import { readData, writeData, EXERCISES_FILE } from '../config/database.js';
import { authenticateToken, requireRole } from '../middleware/auth.js';
import { validateExercise, handleValidationErrors } from '../utils/validation.js';

const router = express.Router();

// Get all exercises
router.get('/', async (req, res) => {
  try {
    const { page = 1, limit = 20, category = '', difficulty = '', muscleGroup = '', search = '' } = req.query;
    const exercises = await readData(EXERCISES_FILE);

    // Apply filters
    let filteredExercises = exercises.filter(exercise => {
      const matchesCategory = !category || exercise.category === category;
      const matchesDifficulty = !difficulty || exercise.difficulty === difficulty;
      const matchesMuscleGroup = !muscleGroup || exercise.muscleGroups.includes(muscleGroup);
      const matchesSearch = !search || 
        exercise.name.toLowerCase().includes(search.toLowerCase()) ||
        exercise.instructions.toLowerCase().includes(search.toLowerCase());
      
      return matchesCategory && matchesDifficulty && matchesMuscleGroup && matchesSearch;
    });

    // Sort by name
    filteredExercises.sort((a, b) => a.name.localeCompare(b.name));

    // Pagination
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    const paginatedExercises = filteredExercises.slice(startIndex, endIndex);

    res.json({
      success: true,
      data: {
        exercises: paginatedExercises,
        pagination: {
          currentPage: parseInt(page),
          totalPages: Math.ceil(filteredExercises.length / limit),
          totalExercises: filteredExercises.length,
          exercisesPerPage: parseInt(limit)
        }
      }
    });
  } catch (error) {
    console.error('Get exercises error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get exercises'
    });
  }
});

// Get exercise by ID
router.get('/:exerciseId', async (req, res) => {
  try {
    const { exerciseId } = req.params;
    const exercises = await readData(EXERCISES_FILE);
    const exercise = exercises.find(e => e.id === exerciseId);

    if (!exercise) {
      return res.status(404).json({
        success: false,
        message: 'Exercise not found'
      });
    }

    res.json({
      success: true,
      data: exercise
    });
  } catch (error) {
    console.error('Get exercise error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get exercise'
    });
  }
});

// Create new exercise (admin only)
router.post('/', authenticateToken, requireRole(['admin']), validateExercise, handleValidationErrors, async (req, res) => {
  try {
    const { name, category, muscleGroups, difficulty, instructions, equipment, imageUrl } = req.body;

    const newExercise = {
      id: uuidv4(),
      name,
      category,
      muscleGroups,
      difficulty,
      instructions: instructions || '',
      equipment: equipment || 'none',
      imageUrl: imageUrl || null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const exercises = await readData(EXERCISES_FILE);
    exercises.push(newExercise);
    await writeData(EXERCISES_FILE, exercises);

    res.status(201).json({
      success: true,
      message: 'Exercise created successfully',
      data: newExercise
    });
  } catch (error) {
    console.error('Create exercise error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create exercise'
    });
  }
});

// Update exercise (admin only)
router.put('/:exerciseId', authenticateToken, requireRole(['admin']), validateExercise, handleValidationErrors, async (req, res) => {
  try {
    const { exerciseId } = req.params;
    const { name, category, muscleGroups, difficulty, instructions, equipment, imageUrl } = req.body;

    const exercises = await readData(EXERCISES_FILE);
    const exerciseIndex = exercises.findIndex(e => e.id === exerciseId);

    if (exerciseIndex === -1) {
      return res.status(404).json({
        success: false,
        message: 'Exercise not found'
      });
    }

    // Update exercise
    const exercise = exercises[exerciseIndex];
    if (name) exercise.name = name;
    if (category) exercise.category = category;
    if (muscleGroups) exercise.muscleGroups = muscleGroups;
    if (difficulty) exercise.difficulty = difficulty;
    if (instructions !== undefined) exercise.instructions = instructions;
    if (equipment !== undefined) exercise.equipment = equipment;
    if (imageUrl !== undefined) exercise.imageUrl = imageUrl;
    exercise.updatedAt = new Date().toISOString();

    await writeData(EXERCISES_FILE, exercises);

    res.json({
      success: true,
      message: 'Exercise updated successfully',
      data: exercise
    });
  } catch (error) {
    console.error('Update exercise error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update exercise'
    });
  }
});

// Delete exercise (admin only)
router.delete('/:exerciseId', authenticateToken, requireRole(['admin']), async (req, res) => {
  try {
    const { exerciseId } = req.params;
    const exercises = await readData(EXERCISES_FILE);
    const exerciseIndex = exercises.findIndex(e => e.id === exerciseId);

    if (exerciseIndex === -1) {
      return res.status(404).json({
        success: false,
        message: 'Exercise not found'
      });
    }

    // Remove exercise
    exercises.splice(exerciseIndex, 1);
    await writeData(EXERCISES_FILE, exercises);

    res.json({
      success: true,
      message: 'Exercise deleted successfully'
    });
  } catch (error) {
    console.error('Delete exercise error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete exercise'
    });
  }
});

// Get exercise categories
router.get('/categories/list', async (req, res) => {
  try {
    const categories = [
      { id: 'bodyweight', name: 'Bodyweight', description: 'Exercises using only body weight' },
      { id: 'strength', name: 'Strength Training', description: 'Weight lifting and resistance exercises' },
      { id: 'cardio', name: 'Cardiovascular', description: 'Aerobic and endurance exercises' },
      { id: 'flexibility', name: 'Flexibility', description: 'Stretching and mobility exercises' },
      { id: 'sports', name: 'Sports', description: 'Sport-specific exercises and drills' }
    ];

    res.json({
      success: true,
      data: categories
    });
  } catch (error) {
    console.error('Get categories error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get categories'
    });
  }
});

// Get muscle groups
router.get('/muscle-groups/list', async (req, res) => {
  try {
    const muscleGroups = [
      { id: 'chest', name: 'Chest', description: 'Pectoral muscles' },
      { id: 'back', name: 'Back', description: 'Latissimus dorsi, rhomboids, trapezius' },
      { id: 'shoulders', name: 'Shoulders', description: 'Deltoid muscles' },
      { id: 'biceps', name: 'Biceps', description: 'Front upper arm muscles' },
      { id: 'triceps', name: 'Triceps', description: 'Back upper arm muscles' },
      { id: 'forearms', name: 'Forearms', description: 'Lower arm muscles' },
      { id: 'abs', name: 'Abs', description: 'Abdominal muscles' },
      { id: 'legs', name: 'Legs', description: 'Quadriceps, hamstrings, calves' },
      { id: 'glutes', name: 'Glutes', description: 'Buttock muscles' },
      { id: 'calves', name: 'Calves', description: 'Lower leg muscles' },
      { id: 'full-body', name: 'Full Body', description: 'Multiple muscle groups' }
    ];

    res.json({
      success: true,
      data: muscleGroups
    });
  } catch (error) {
    console.error('Get muscle groups error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get muscle groups'
    });
  }
});

// Get difficulty levels
router.get('/difficulty-levels/list', async (req, res) => {
  try {
    const difficultyLevels = [
      { id: 'beginner', name: 'Beginner', description: 'Suitable for beginners' },
      { id: 'intermediate', name: 'Intermediate', description: 'Moderate difficulty' },
      { id: 'advanced', name: 'Advanced', description: 'High difficulty level' }
    ];

    res.json({
      success: true,
      data: difficultyLevels
    });
  } catch (error) {
    console.error('Get difficulty levels error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get difficulty levels'
    });
  }
});

// Get exercise statistics
router.get('/stats/overview', authenticateToken, requireRole(['admin']), async (req, res) => {
  try {
    const exercises = await readData(EXERCISES_FILE);

    const stats = {
      totalExercises: exercises.length,
      categoryDistribution: {
        bodyweight: exercises.filter(e => e.category === 'bodyweight').length,
        strength: exercises.filter(e => e.category === 'strength').length,
        cardio: exercises.filter(e => e.category === 'cardio').length,
        flexibility: exercises.filter(e => e.category === 'flexibility').length,
        sports: exercises.filter(e => e.category === 'sports').length
      },
      difficultyDistribution: {
        beginner: exercises.filter(e => e.difficulty === 'beginner').length,
        intermediate: exercises.filter(e => e.difficulty === 'intermediate').length,
        advanced: exercises.filter(e => e.difficulty === 'advanced').length
      },
      muscleGroupDistribution: exercises.reduce((acc, exercise) => {
        exercise.muscleGroups.forEach(group => {
          acc[group] = (acc[group] || 0) + 1;
        });
        return acc;
      }, {}),
      equipmentDistribution: exercises.reduce((acc, exercise) => {
        acc[exercise.equipment] = (acc[exercise.equipment] || 0) + 1;
        return acc;
      }, {})
    };

    res.json({
      success: true,
      data: stats
    });
  } catch (error) {
    console.error('Get exercise stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get exercise statistics'
    });
  }
});

export default router; 