import express from 'express';
import { v4 as uuidv4 } from 'uuid';
import { readData, writeData, PROGRESS_FILE } from '../config/database.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

// Get progress entries for current user
router.get('/', authenticateToken, async (req, res) => {
  try {
    const { page = 1, limit = 10, type = '', startDate = '', endDate = '' } = req.query;
    const progressEntries = await readData(PROGRESS_FILE);
    
    // Filter by user
    let userEntries = progressEntries.filter(entry => entry.userId === req.user.id);

    // Apply filters
    if (type) {
      userEntries = userEntries.filter(entry => entry.type === type);
    }
    if (startDate) {
      userEntries = userEntries.filter(entry => new Date(entry.date) >= new Date(startDate));
    }
    if (endDate) {
      userEntries = userEntries.filter(entry => new Date(entry.date) <= new Date(endDate));
    }

    // Sort by date (newest first)
    userEntries.sort((a, b) => new Date(b.date) - new Date(a.date));

    // Pagination
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    const paginatedEntries = userEntries.slice(startIndex, endIndex);

    res.json({
      success: true,
      data: {
        entries: paginatedEntries,
        pagination: {
          currentPage: parseInt(page),
          totalPages: Math.ceil(userEntries.length / limit),
          totalEntries: userEntries.length,
          entriesPerPage: parseInt(limit)
        }
      }
    });
  } catch (error) {
    console.error('Get progress entries error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get progress entries'
    });
  }
});

// Get progress entry by ID
router.get('/:entryId', authenticateToken, async (req, res) => {
  try {
    const { entryId } = req.params;
    const progressEntries = await readData(PROGRESS_FILE);
    const entry = progressEntries.find(e => e.id === entryId && e.userId === req.user.id);

    if (!entry) {
      return res.status(404).json({
        success: false,
        message: 'Progress entry not found'
      });
    }

    res.json({
      success: true,
      data: entry
    });
  } catch (error) {
    console.error('Get progress entry error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get progress entry'
    });
  }
});

// Create progress entry
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { type, date, measurements, notes = '' } = req.body;

    if (!type || !date || !measurements) {
      return res.status(400).json({
        success: false,
        message: 'Type, date, and measurements are required'
      });
    }

    const newEntry = {
      id: uuidv4(),
      userId: req.user.id,
      type,
      date,
      measurements,
      notes,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const progressEntries = await readData(PROGRESS_FILE);
    progressEntries.push(newEntry);
    await writeData(PROGRESS_FILE, progressEntries);

    res.status(201).json({
      success: true,
      message: 'Progress entry created successfully',
      data: newEntry
    });
  } catch (error) {
    console.error('Create progress entry error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create progress entry'
    });
  }
});

// Update progress entry
router.put('/:entryId', authenticateToken, async (req, res) => {
  try {
    const { entryId } = req.params;
    const { type, date, measurements, notes } = req.body;

    const progressEntries = await readData(PROGRESS_FILE);
    const entryIndex = progressEntries.findIndex(e => e.id === entryId && e.userId === req.user.id);

    if (entryIndex === -1) {
      return res.status(404).json({
        success: false,
        message: 'Progress entry not found'
      });
    }

    // Update entry
    const entry = progressEntries[entryIndex];
    if (type) entry.type = type;
    if (date) entry.date = date;
    if (measurements) entry.measurements = measurements;
    if (notes !== undefined) entry.notes = notes;
    entry.updatedAt = new Date().toISOString();

    await writeData(PROGRESS_FILE, progressEntries);

    res.json({
      success: true,
      message: 'Progress entry updated successfully',
      data: entry
    });
  } catch (error) {
    console.error('Update progress entry error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update progress entry'
    });
  }
});

// Delete progress entry
router.delete('/:entryId', authenticateToken, async (req, res) => {
  try {
    const { entryId } = req.params;
    const progressEntries = await readData(PROGRESS_FILE);
    const entryIndex = progressEntries.findIndex(e => e.id === entryId && e.userId === req.user.id);

    if (entryIndex === -1) {
      return res.status(404).json({
        success: false,
        message: 'Progress entry not found'
      });
    }

    // Remove entry
    progressEntries.splice(entryIndex, 1);
    await writeData(PROGRESS_FILE, progressEntries);

    res.json({
      success: true,
      message: 'Progress entry deleted successfully'
    });
  } catch (error) {
    console.error('Delete progress entry error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete progress entry'
    });
  }
});

// Get progress statistics
router.get('/stats/overview', authenticateToken, async (req, res) => {
  try {
    const { period = '30' } = req.query; // days
    const progressEntries = await readData(PROGRESS_FILE);
    const userEntries = progressEntries.filter(entry => entry.userId === req.user.id);

    // Filter by period
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - parseInt(period));
    const recentEntries = userEntries.filter(entry => new Date(entry.date) >= cutoffDate);

    // Group by type
    const entriesByType = userEntries.reduce((acc, entry) => {
      if (!acc[entry.type]) {
        acc[entry.type] = [];
      }
      acc[entry.type].push(entry);
      return acc;
    }, {});

    // Calculate trends for each measurement type
    const trends = {};
    Object.keys(entriesByType).forEach(type => {
      const entries = entriesByType[type].sort((a, b) => new Date(a.date) - new Date(b.date));
      if (entries.length >= 2) {
        const firstEntry = entries[0];
        const lastEntry = entries[entries.length - 1];
        
        trends[type] = {};
        Object.keys(firstEntry.measurements).forEach(measurement => {
          const firstValue = firstEntry.measurements[measurement];
          const lastValue = lastEntry.measurements[measurement];
          if (typeof firstValue === 'number' && typeof lastValue === 'number') {
            trends[type][measurement] = {
              change: lastValue - firstValue,
              percentageChange: ((lastValue - firstValue) / firstValue) * 100,
              firstValue,
              lastValue
            };
          }
        });
      }
    });

    const stats = {
      totalEntries: userEntries.length,
      recentEntries: recentEntries.length,
      entriesByType: Object.keys(entriesByType).reduce((acc, type) => {
        acc[type] = entriesByType[type].length;
        return acc;
      }, {}),
      trends,
      latestEntries: userEntries
        .sort((a, b) => new Date(b.date) - new Date(a.date))
        .slice(0, 5)
    };

    res.json({
      success: true,
      data: stats
    });
  } catch (error) {
    console.error('Get progress stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get progress statistics'
    });
  }
});

// Get progress goals
router.get('/goals', authenticateToken, async (req, res) => {
  try {
    const defaultGoals = {
      weight: {
        target: 70,
        unit: 'kg',
        description: 'Target weight'
      },
      bodyFat: {
        target: 15,
        unit: '%',
        description: 'Target body fat percentage'
      },
      muscleMass: {
        target: 60,
        unit: 'kg',
        description: 'Target muscle mass'
      },
      chest: {
        target: 100,
        unit: 'cm',
        description: 'Target chest circumference'
      },
      waist: {
        target: 80,
        unit: 'cm',
        description: 'Target waist circumference'
      },
      arms: {
        target: 35,
        unit: 'cm',
        description: 'Target arm circumference'
      },
      legs: {
        target: 60,
        unit: 'cm',
        description: 'Target leg circumference'
      }
    };

    res.json({
      success: true,
      data: defaultGoals
    });
  } catch (error) {
    console.error('Get progress goals error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get progress goals'
    });
  }
});

// Get measurement types
router.get('/measurement-types', authenticateToken, async (req, res) => {
  try {
    const measurementTypes = [
      {
        id: 'weight',
        name: 'Weight',
        unit: 'kg',
        description: 'Body weight measurement'
      },
      {
        id: 'bodyFat',
        name: 'Body Fat',
        unit: '%',
        description: 'Body fat percentage'
      },
      {
        id: 'muscleMass',
        name: 'Muscle Mass',
        unit: 'kg',
        description: 'Muscle mass measurement'
      },
      {
        id: 'chest',
        name: 'Chest',
        unit: 'cm',
        description: 'Chest circumference'
      },
      {
        id: 'waist',
        name: 'Waist',
        unit: 'cm',
        description: 'Waist circumference'
      },
      {
        id: 'arms',
        name: 'Arms',
        unit: 'cm',
        description: 'Arm circumference'
      },
      {
        id: 'legs',
        name: 'Legs',
        unit: 'cm',
        description: 'Leg circumference'
      },
      {
        id: 'height',
        name: 'Height',
        unit: 'cm',
        description: 'Height measurement'
      },
      {
        id: 'bmi',
        name: 'BMI',
        unit: '',
        description: 'Body Mass Index'
      }
    ];

    res.json({
      success: true,
      data: measurementTypes
    });
  } catch (error) {
    console.error('Get measurement types error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get measurement types'
    });
  }
});

export default router; 