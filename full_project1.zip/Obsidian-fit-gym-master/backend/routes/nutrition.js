import express from 'express';
import { v4 as uuidv4 } from 'uuid';
import { readData, writeData, NUTRITION_FILE } from '../config/database.js';
import { authenticateToken } from '../middleware/auth.js';
import { validateNutrition, handleValidationErrors } from '../utils/validation.js';

const router = express.Router();

// Get nutrition entries for current user
router.get('/', authenticateToken, async (req, res) => {
  try {
    const { page = 1, limit = 10, startDate = '', endDate = '' } = req.query;
    const nutritionEntries = await readData(NUTRITION_FILE);
    
    // Filter by user
    let userEntries = nutritionEntries.filter(entry => entry.userId === req.user.id);

    // Apply date filters
    if (startDate) {
      userEntries = userEntries.filter(entry => new Date(entry.date) >= new Date(startDate));
    }
    if (endDate) {
      userEntries = userEntries.filter(entry => new Date(entry.date) <= new Date(endDate));
    }

    // Sort by date (newest first)
    userEntries.sort((a, b) => new Date(b.date) - new Date(a.date));

    // Pagination
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    const paginatedEntries = userEntries.slice(startIndex, endIndex);

    res.json({
      success: true,
      data: {
        entries: paginatedEntries,
        pagination: {
          currentPage: parseInt(page),
          totalPages: Math.ceil(userEntries.length / limit),
          totalEntries: userEntries.length,
          entriesPerPage: parseInt(limit)
        }
      }
    });
  } catch (error) {
    console.error('Get nutrition entries error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get nutrition entries'
    });
  }
});

// Get nutrition entry by ID
router.get('/:entryId', authenticateToken, async (req, res) => {
  try {
    const { entryId } = req.params;
    const nutritionEntries = await readData(NUTRITION_FILE);
    const entry = nutritionEntries.find(e => e.id === entryId && e.userId === req.user.id);

    if (!entry) {
      return res.status(404).json({
        success: false,
        message: 'Nutrition entry not found'
      });
    }

    res.json({
      success: true,
      data: entry
    });
  } catch (error) {
    console.error('Get nutrition entry error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get nutrition entry'
    });
  }
});

// Create nutrition entry
router.post('/', authenticateToken, validateNutrition, handleValidationErrors, async (req, res) => {
  try {
    const { date, meals, notes = '' } = req.body;

    // Check if entry already exists for this date
    const nutritionEntries = await readData(NUTRITION_FILE);
    const existingEntry = nutritionEntries.find(
      e => e.userId === req.user.id && e.date === date
    );

    if (existingEntry) {
      return res.status(409).json({
        success: false,
        message: 'Nutrition entry already exists for this date'
      });
    }

    const newEntry = {
      id: uuidv4(),
      userId: req.user.id,
      date,
      meals,
      notes,
      totalCalories: meals.reduce((sum, meal) => sum + (meal.calories || 0), 0),
      totalProtein: meals.reduce((sum, meal) => sum + (meal.protein || 0), 0),
      totalCarbs: meals.reduce((sum, meal) => sum + (meal.carbs || 0), 0),
      totalFat: meals.reduce((sum, meal) => sum + (meal.fat || 0), 0),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    nutritionEntries.push(newEntry);
    await writeData(NUTRITION_FILE, nutritionEntries);

    res.status(201).json({
      success: true,
      message: 'Nutrition entry created successfully',
      data: newEntry
    });
  } catch (error) {
    console.error('Create nutrition entry error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create nutrition entry'
    });
  }
});

// Update nutrition entry
router.put('/:entryId', authenticateToken, validateNutrition, handleValidationErrors, async (req, res) => {
  try {
    const { entryId } = req.params;
    const { date, meals, notes } = req.body;

    const nutritionEntries = await readData(NUTRITION_FILE);
    const entryIndex = nutritionEntries.findIndex(e => e.id === entryId && e.userId === req.user.id);

    if (entryIndex === -1) {
      return res.status(404).json({
        success: false,
        message: 'Nutrition entry not found'
      });
    }

    // Update entry
    const entry = nutritionEntries[entryIndex];
    if (date) entry.date = date;
    if (meals) {
      entry.meals = meals;
      entry.totalCalories = meals.reduce((sum, meal) => sum + (meal.calories || 0), 0);
      entry.totalProtein = meals.reduce((sum, meal) => sum + (meal.protein || 0), 0);
      entry.totalCarbs = meals.reduce((sum, meal) => sum + (meal.carbs || 0), 0);
      entry.totalFat = meals.reduce((sum, meal) => sum + (meal.fat || 0), 0);
    }
    if (notes !== undefined) entry.notes = notes;
    entry.updatedAt = new Date().toISOString();

    await writeData(NUTRITION_FILE, nutritionEntries);

    res.json({
      success: true,
      message: 'Nutrition entry updated successfully',
      data: entry
    });
  } catch (error) {
    console.error('Update nutrition entry error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update nutrition entry'
    });
  }
});

// Delete nutrition entry
router.delete('/:entryId', authenticateToken, async (req, res) => {
  try {
    const { entryId } = req.params;
    const nutritionEntries = await readData(NUTRITION_FILE);
    const entryIndex = nutritionEntries.findIndex(e => e.id === entryId && e.userId === req.user.id);

    if (entryIndex === -1) {
      return res.status(404).json({
        success: false,
        message: 'Nutrition entry not found'
      });
    }

    // Remove entry
    nutritionEntries.splice(entryIndex, 1);
    await writeData(NUTRITION_FILE, nutritionEntries);

    res.json({
      success: true,
      message: 'Nutrition entry deleted successfully'
    });
  } catch (error) {
    console.error('Delete nutrition entry error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete nutrition entry'
    });
  }
});

// Get nutrition statistics
router.get('/stats/overview', authenticateToken, async (req, res) => {
  try {
    const { period = '30' } = req.query; // days
    const nutritionEntries = await readData(NUTRITION_FILE);
    const userEntries = nutritionEntries.filter(entry => entry.userId === req.user.id);

    // Filter by period
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - parseInt(period));
    const recentEntries = userEntries.filter(entry => new Date(entry.date) >= cutoffDate);

    const stats = {
      totalEntries: userEntries.length,
      recentEntries: recentEntries.length,
      averageCalories: recentEntries.length > 0 
        ? recentEntries.reduce((sum, entry) => sum + entry.totalCalories, 0) / recentEntries.length 
        : 0,
      averageProtein: recentEntries.length > 0 
        ? recentEntries.reduce((sum, entry) => sum + entry.totalProtein, 0) / recentEntries.length 
        : 0,
      averageCarbs: recentEntries.length > 0 
        ? recentEntries.reduce((sum, entry) => sum + entry.totalCarbs, 0) / recentEntries.length 
        : 0,
      averageFat: recentEntries.length > 0 
        ? recentEntries.reduce((sum, entry) => sum + entry.totalFat, 0) / recentEntries.length 
        : 0,
      dailyAverages: recentEntries.reduce((acc, entry) => {
        const date = entry.date;
        if (!acc[date]) {
          acc[date] = {
            calories: 0,
            protein: 0,
            carbs: 0,
            fat: 0,
            count: 0
          };
        }
        acc[date].calories += entry.totalCalories;
        acc[date].protein += entry.totalProtein;
        acc[date].carbs += entry.totalCarbs;
        acc[date].fat += entry.totalFat;
        acc[date].count += 1;
        return acc;
      }, {})
    };

    res.json({
      success: true,
      data: stats
    });
  } catch (error) {
    console.error('Get nutrition stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get nutrition statistics'
    });
  }
});

// Get meal suggestions
router.get('/suggestions/meals', authenticateToken, async (req, res) => {
  try {
    const { mealType = '', calories = '' } = req.query;
    
    const mealSuggestions = [
      {
        id: 'meal-1',
        name: 'Grilled Chicken Breast',
        mealType: 'lunch',
        calories: 165,
        protein: 31,
        carbs: 0,
        fat: 3.6,
        ingredients: ['chicken breast', 'olive oil', 'herbs'],
        instructions: 'Season and grill chicken breast until cooked through'
      },
      {
        id: 'meal-2',
        name: 'Oatmeal with Berries',
        mealType: 'breakfast',
        calories: 150,
        protein: 6,
        carbs: 27,
        fat: 3,
        ingredients: ['oats', 'berries', 'honey', 'milk'],
        instructions: 'Cook oats with milk, top with berries and honey'
      },
      {
        id: 'meal-3',
        name: 'Salmon with Vegetables',
        mealType: 'dinner',
        calories: 280,
        protein: 34,
        carbs: 8,
        fat: 15,
        ingredients: ['salmon fillet', 'broccoli', 'carrots', 'olive oil'],
        instructions: 'Bake salmon with vegetables until fish flakes easily'
      },
      {
        id: 'meal-4',
        name: 'Greek Yogurt with Nuts',
        mealType: 'snack',
        calories: 120,
        protein: 15,
        carbs: 8,
        fat: 6,
        ingredients: ['greek yogurt', 'almonds', 'honey'],
        instructions: 'Mix yogurt with chopped nuts and drizzle with honey'
      }
    ];

    let filteredMeals = mealSuggestions;
    if (mealType) {
      filteredMeals = filteredMeals.filter(meal => meal.mealType === mealType);
    }
    if (calories) {
      const maxCalories = parseInt(calories);
      filteredMeals = filteredMeals.filter(meal => meal.calories <= maxCalories);
    }

    res.json({
      success: true,
      data: filteredMeals
    });
  } catch (error) {
    console.error('Get meal suggestions error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get meal suggestions'
    });
  }
});

// Get nutrition goals
router.get('/goals', authenticateToken, async (req, res) => {
  try {
    const defaultGoals = {
      calories: 2000,
      protein: 150,
      carbs: 250,
      fat: 65,
      fiber: 25,
      sugar: 50
    };

    res.json({
      success: true,
      data: defaultGoals
    });
  } catch (error) {
    console.error('Get nutrition goals error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get nutrition goals'
    });
  }
});

export default router; 