import express from 'express';
import { readData, writeData, USERS_FILE } from '../config/database.js';
import { authenticateToken, requireRole } from '../middleware/auth.js';
import { validateUserUpdate, handleValidationErrors } from '../utils/validation.js';

const router = express.Router();

// Get user profile by ID
router.get('/:userId', authenticateToken, async (req, res) => {
  try {
    const { userId } = req.params;
    const users = await readData(USERS_FILE);
    const user = users.find(u => u.id === userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Remove password from response
    const { password: _, ...userResponse } = user;

    res.json({
      success: true,
      data: userResponse
    });
  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get user'
    });
  }
});

// Update user profile
router.put('/profile', authenticateToken, validateUserUpdate, handleValidationErrors, async (req, res) => {
  try {
    const { username, email, dob, phoneNumber, address, preferences } = req.body;
    const users = await readData(USERS_FILE);
    const userIndex = users.findIndex(u => u.id === req.user.id);

    if (userIndex === -1) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Check if username or email already exists (excluding current user)
    if (username) {
      const existingUser = users.find(
        u => u.id !== req.user.id && 
             u.username.toLowerCase() === username.toLowerCase()
      );
      if (existingUser) {
        return res.status(409).json({
          success: false,
          message: 'Username already exists'
        });
      }
    }

    if (email) {
      const existingUser = users.find(
        u => u.id !== req.user.id && 
             u.email.toLowerCase() === email.toLowerCase()
      );
      if (existingUser) {
        return res.status(409).json({
          success: false,
          message: 'Email already exists'
        });
      }
    }

    // Update user fields
    const user = users[userIndex];
    if (username) user.username = username;
    if (email) user.email = email.toLowerCase();
    if (dob) user.dob = dob;
    if (phoneNumber) user.phoneNumber = phoneNumber;
    if (address) user.address = { ...user.address, ...address };
    if (preferences) user.preferences = { ...user.preferences, ...preferences };
    
    user.updatedAt = new Date().toISOString();

    await writeData(USERS_FILE, users);

    // Remove password from response
    const { password: _, ...userResponse } = user;

    res.json({
      success: true,
      message: 'Profile updated successfully',
      data: userResponse
    });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update profile'
    });
  }
});

// Upload profile picture
router.post('/profile-picture', authenticateToken, async (req, res) => {
  try {
    const { profilePicture } = req.body;

    if (!profilePicture) {
      return res.status(400).json({
        success: false,
        message: 'Profile picture is required'
      });
    }

    const users = await readData(USERS_FILE);
    const userIndex = users.findIndex(u => u.id === req.user.id);

    if (userIndex === -1) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Update profile picture
    users[userIndex].profilePicture = profilePicture;
    users[userIndex].updatedAt = new Date().toISOString();

    await writeData(USERS_FILE, users);

    res.json({
      success: true,
      message: 'Profile picture updated successfully',
      data: { profilePicture }
    });
  } catch (error) {
    console.error('Update profile picture error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update profile picture'
    });
  }
});

// Get all users (admin only)
router.get('/', authenticateToken, requireRole(['admin']), async (req, res) => {
  try {
    const { page = 1, limit = 10, search = '', role = '' } = req.query;
    const users = await readData(USERS_FILE);

    // Filter users
    let filteredUsers = users.filter(user => {
      const matchesSearch = !search || 
        user.username.toLowerCase().includes(search.toLowerCase()) ||
        user.email.toLowerCase().includes(search.toLowerCase());
      const matchesRole = !role || user.role === role;
      return matchesSearch && matchesRole;
    });

    // Remove passwords from response
    filteredUsers = filteredUsers.map(user => {
      const { password: _, ...userResponse } = user;
      return userResponse;
    });

    // Pagination
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    const paginatedUsers = filteredUsers.slice(startIndex, endIndex);

    res.json({
      success: true,
      data: {
        users: paginatedUsers,
        pagination: {
          currentPage: parseInt(page),
          totalPages: Math.ceil(filteredUsers.length / limit),
          totalUsers: filteredUsers.length,
          usersPerPage: parseInt(limit)
        }
      }
    });
  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get users'
    });
  }
});

// Update user status (admin only)
router.put('/:userId/status', authenticateToken, requireRole(['admin']), async (req, res) => {
  try {
    const { userId } = req.params;
    const { accountStatus, accountLocked } = req.body;

    const users = await readData(USERS_FILE);
    const userIndex = users.findIndex(u => u.id === userId);

    if (userIndex === -1) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Update user status
    if (accountStatus) users[userIndex].accountStatus = accountStatus;
    if (typeof accountLocked === 'boolean') users[userIndex].accountLocked = accountLocked;
    users[userIndex].updatedAt = new Date().toISOString();

    await writeData(USERS_FILE, users);

    // Remove password from response
    const { password: _, ...userResponse } = users[userIndex];

    res.json({
      success: true,
      message: 'User status updated successfully',
      data: userResponse
    });
  } catch (error) {
    console.error('Update user status error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update user status'
    });
  }
});

// Delete user (admin only)
router.delete('/:userId', authenticateToken, requireRole(['admin']), async (req, res) => {
  try {
    const { userId } = req.params;

    if (userId === req.user.id) {
      return res.status(400).json({
        success: false,
        message: 'Cannot delete your own account'
      });
    }

    const users = await readData(USERS_FILE);
    const userIndex = users.findIndex(u => u.id === userId);

    if (userIndex === -1) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Remove user
    users.splice(userIndex, 1);
    await writeData(USERS_FILE, users);

    res.json({
      success: true,
      message: 'User deleted successfully'
    });
  } catch (error) {
    console.error('Delete user error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete user'
    });
  }
});

// Get user statistics
router.get('/stats/overview', authenticateToken, async (req, res) => {
  try {
    const users = await readData(USERS_FILE);
    
    const stats = {
      totalUsers: users.length,
      activeUsers: users.filter(u => u.accountStatus === 'active').length,
      lockedUsers: users.filter(u => u.accountLocked).length,
      verifiedUsers: users.filter(u => u.isEmailVerified).length,
      recentRegistrations: users.filter(u => {
        const registrationDate = new Date(u.createdAt);
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        return registrationDate > thirtyDaysAgo;
      }).length,
      roleDistribution: {
        user: users.filter(u => u.role === 'user').length,
        admin: users.filter(u => u.role === 'admin').length
      }
    };

    res.json({
      success: true,
      data: stats
    });
  } catch (error) {
    console.error('Get user stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get user statistics'
    });
  }
});

export default router; 