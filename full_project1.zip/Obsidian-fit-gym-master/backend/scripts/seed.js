import { readData, writeData, USERS_FILE, EXERCISES_FILE } from '../config/database.js';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';

const seedDatabase = async () => {
  try {
    console.log('🌱 Starting database seeding...');

    // Seed admin user
    const users = await readData(USERS_FILE);
    const adminExists = users.find(u => u.role === 'admin');
    
    if (!adminExists) {
      const saltRounds = 12;
      const hashedPassword = await bcrypt.hash('admin123', saltRounds);
      
      const adminUser = {
        id: uuidv4(),
        username: 'admin',
        email: 'admin@fithub.com',
        password: hashedPassword,
        dob: '1990-01-01',
        profilePicture: null,
        phoneNumber: null,
        address: {
          street: null,
          city: null,
          state: null,
          zipCode: null,
          country: 'India'
        },
        preferences: {
          theme: 'light',
          notifications: true,
          language: 'en'
        },
        accountStatus: 'active',
        lastLogin: null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        role: 'admin',
        isEmailVerified: true,
        loginAttempts: 0,
        accountLocked: false
      };

      users.push(adminUser);
      await writeData(USERS_FILE, users);
      console.log('✅ Admin user created');
    } else {
      console.log('ℹ️ Admin user already exists');
    }

    // Seed additional exercises
    const exercises = await readData(EXERCISES_FILE);
    const additionalExercises = [
      {
        id: '4',
        name: 'Bench Press',
        category: 'strength',
        muscleGroups: ['chest', 'triceps', 'shoulders'],
        difficulty: 'intermediate',
        instructions: 'Lie on bench, lower bar to chest, press up',
        equipment: 'barbell',
        imageUrl: null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: '5',
        name: 'Deadlift',
        category: 'strength',
        muscleGroups: ['back', 'legs', 'glutes'],
        difficulty: 'advanced',
        instructions: 'Stand with feet shoulder-width, grip bar, lift with straight back',
        equipment: 'barbell',
        imageUrl: null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: '6',
        name: 'Running',
        category: 'cardio',
        muscleGroups: ['legs', 'full-body'],
        difficulty: 'beginner',
        instructions: 'Run at moderate pace for cardiovascular fitness',
        equipment: 'none',
        imageUrl: null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: '7',
        name: 'Plank',
        category: 'bodyweight',
        muscleGroups: ['abs', 'core'],
        difficulty: 'beginner',
        instructions: 'Hold body in straight line from head to heels',
        equipment: 'none',
        imageUrl: null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: '8',
        name: 'Lunges',
        category: 'bodyweight',
        muscleGroups: ['legs', 'glutes'],
        difficulty: 'beginner',
        instructions: 'Step forward, lower back knee, return to start',
        equipment: 'none',
        imageUrl: null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ];

    // Add new exercises if they don't exist
    let addedCount = 0;
    for (const exercise of additionalExercises) {
      const exists = exercises.find(e => e.id === exercise.id);
      if (!exists) {
        exercises.push(exercise);
        addedCount++;
      }
    }

    if (addedCount > 0) {
      await writeData(EXERCISES_FILE, exercises);
      console.log(`✅ Added ${addedCount} new exercises`);
    } else {
      console.log('ℹ️ All exercises already exist');
    }

    console.log('🎉 Database seeding completed successfully!');
    console.log('\n📋 Default credentials:');
    console.log('   Username: admin');
    console.log('   Password: admin123');
    console.log('\n🔗 API Health Check: http://localhost:5000/api/health');
    console.log('📚 API Documentation: http://localhost:5000/api');

  } catch (error) {
    console.error('❌ Database seeding failed:', error);
    process.exit(1);
  }
};

// Run seeding if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  seedDatabase();
}

export default seedDatabase; 