import { readData, writeData, USERS_FILE } from '../config/database.js';
import bcrypt from 'bcryptjs';

const resetAdminPassword = async () => {
  try {
    console.log('🔧 Resetting admin password...');

    // Read current users
    const users = await readData(USERS_FILE);
    
    // Find admin user
    const adminUser = users.find(u => u.username === 'admin');
    
    if (!adminUser) {
      console.log('❌ Admin user not found');
      return;
    }

    // Hash new password
    const saltRounds = 12;
    const newPassword = 'admin123';
    const hashedPassword = await bcrypt.hash(newPassword, saltRounds);
    
    // Update admin password
    adminUser.password = hashedPassword;
    adminUser.updatedAt = new Date().toISOString();
    
    // Save updated users
    await writeData(USERS_FILE, users);
    
    console.log('✅ Admin password reset successfully!');
    console.log('📋 New credentials:');
    console.log('   Username: admin');
    console.log('   Password: admin123');
    
  } catch (error) {
    console.error('❌ Failed to reset admin password:', error);
  }
};

// Run if executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  resetAdminPassword();
}

export default resetAdminPassword; 