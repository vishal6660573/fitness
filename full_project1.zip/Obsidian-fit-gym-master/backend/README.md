# FitHub Backend API

A complete RESTful API backend for the FitHub fitness application, built with Node.js, Express, and JSON file-based storage.

## Features

- 🔐 **Authentication & Authorization**: JWT-based authentication with role-based access control
- 👥 **User Management**: User registration, login, profile management, and admin controls
- 💪 **Workout Management**: Create, track, and manage workout routines
- 🏋️ **Exercise Library**: Comprehensive exercise database with filtering and categorization
- 🥗 **Nutrition Tracking**: Meal planning and nutrition logging
- 📊 **Progress Tracking**: Fitness progress monitoring with statistics and trends
- 🔒 **Security**: Rate limiting, input validation, and security headers
- 📈 **Statistics**: Comprehensive analytics and reporting

## Tech Stack

- **Runtime**: Node.js
- **Framework**: Express.js
- **Authentication**: JWT (JSON Web Tokens)
- **Password Hashing**: bcryptjs
- **Validation**: express-validator
- **Security**: helmet, cors, rate-limiting
- **Storage**: JSON file-based (easily replaceable with MongoDB/PostgreSQL)

## Quick Start

### Prerequisites

- Node.js (v16 or higher)
- npm or yarn

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd backend
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp env.example .env
   ```
   
   Edit `.env` file with your configuration:
   ```env
   PORT=5000
   NODE_ENV=development
   JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
   JWT_EXPIRES_IN=7d
   ```

4. **Start the server**
   ```bash
   # Development mode
   npm run dev
   
   # Production mode
   npm start
   ```

The server will start on `http://localhost:5000`

## API Endpoints

### Authentication

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register new user |
| POST | `/api/auth/login` | User login |
| GET | `/api/auth/me` | Get current user profile |
| POST | `/api/auth/refresh` | Refresh JWT token |
| POST | `/api/auth/logout` | Logout user |
| PUT | `/api/auth/change-password` | Change password |

### Users

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/users/:userId` | Get user profile |
| PUT | `/api/users/profile` | Update user profile |
| POST | `/api/users/profile-picture` | Upload profile picture |
| GET | `/api/users/` | Get all users (admin) |
| PUT | `/api/users/:userId/status` | Update user status (admin) |
| DELETE | `/api/users/:userId` | Delete user (admin) |
| GET | `/api/users/stats/overview` | Get user statistics |

### Workouts

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/workouts/` | Get user workouts |
| GET | `/api/workouts/:workoutId` | Get specific workout |
| POST | `/api/workouts/` | Create new workout |
| PUT | `/api/workouts/:workoutId` | Update workout |
| PATCH | `/api/workouts/:workoutId/complete` | Complete workout |
| DELETE | `/api/workouts/:workoutId` | Delete workout |
| GET | `/api/workouts/stats/overview` | Get workout statistics |
| GET | `/api/workouts/templates` | Get workout templates |

### Exercises

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/exercises/` | Get all exercises |
| GET | `/api/exercises/:exerciseId` | Get specific exercise |
| POST | `/api/exercises/` | Create exercise (admin) |
| PUT | `/api/exercises/:exerciseId` | Update exercise (admin) |
| DELETE | `/api/exercises/:exerciseId` | Delete exercise (admin) |
| GET | `/api/exercises/categories/list` | Get exercise categories |
| GET | `/api/exercises/muscle-groups/list` | Get muscle groups |
| GET | `/api/exercises/difficulty-levels/list` | Get difficulty levels |
| GET | `/api/exercises/stats/overview` | Get exercise statistics |

### Nutrition

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/nutrition/` | Get nutrition entries |
| GET | `/api/nutrition/:entryId` | Get specific entry |
| POST | `/api/nutrition/` | Create nutrition entry |
| PUT | `/api/nutrition/:entryId` | Update nutrition entry |
| DELETE | `/api/nutrition/:entryId` | Delete nutrition entry |
| GET | `/api/nutrition/stats/overview` | Get nutrition statistics |
| GET | `/api/nutrition/suggestions/meals` | Get meal suggestions |
| GET | `/api/nutrition/goals` | Get nutrition goals |

### Progress

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/progress/` | Get progress entries |
| GET | `/api/progress/:entryId` | Get specific entry |
| POST | `/api/progress/` | Create progress entry |
| PUT | `/api/progress/:entryId` | Update progress entry |
| DELETE | `/api/progress/:entryId` | Delete progress entry |
| GET | `/api/progress/stats/overview` | Get progress statistics |
| GET | `/api/progress/goals` | Get progress goals |
| GET | `/api/progress/measurement-types` | Get measurement types |

## Authentication

The API uses JWT (JSON Web Tokens) for authentication. Include the token in the Authorization header:

```
Authorization: Bearer <your-jwt-token>
```

## Request/Response Format

### Success Response
```json
{
  "success": true,
  "message": "Operation successful",
  "data": {
    // Response data
  }
}
```

### Error Response
```json
{
  "success": false,
  "message": "Error description",
  "errors": [
    {
      "field": "fieldName",
      "message": "Validation error message"
    }
  ]
}
```

## Data Models

### User
```json
{
  "id": "uuid",
  "username": "string",
  "email": "string",
  "dob": "date",
  "profilePicture": "string|null",
  "phoneNumber": "string|null",
  "address": {
    "street": "string|null",
    "city": "string|null",
    "state": "string|null",
    "zipCode": "string|null",
    "country": "string"
  },
  "preferences": {
    "theme": "light|dark",
    "notifications": "boolean",
    "language": "string"
  },
  "accountStatus": "active|inactive",
  "role": "user|admin",
  "isEmailVerified": "boolean",
  "loginAttempts": "number",
  "accountLocked": "boolean",
  "lastLogin": "date|null",
  "createdAt": "date",
  "updatedAt": "date"
}
```

### Workout
```json
{
  "id": "uuid",
  "userId": "uuid",
  "name": "string",
  "description": "string",
  "category": "strength|cardio|flexibility|sports",
  "difficulty": "beginner|intermediate|advanced",
  "exercises": [
    {
      "exerciseId": "uuid",
      "sets": "number",
      "reps": "number|null",
      "weight": "number|null",
      "duration": "number|null"
    }
  ],
  "isCompleted": "boolean",
  "completedAt": "date|null",
  "duration": "number|null",
  "notes": "string",
  "createdAt": "date",
  "updatedAt": "date"
}
```

### Exercise
```json
{
  "id": "uuid",
  "name": "string",
  "category": "bodyweight|strength|cardio|flexibility|sports",
  "muscleGroups": ["string"],
  "difficulty": "beginner|intermediate|advanced",
  "instructions": "string",
  "equipment": "string",
  "imageUrl": "string|null",
  "createdAt": "date",
  "updatedAt": "date"
}
```

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `PORT` | Server port | `5000` |
| `NODE_ENV` | Environment | `development` |
| `JWT_SECRET` | JWT secret key | Required |
| `JWT_EXPIRES_IN` | JWT expiration | `7d` |
| `BCRYPT_ROUNDS` | Password hashing rounds | `12` |
| `RATE_LIMIT_WINDOW_MS` | Rate limit window | `900000` (15 min) |
| `RATE_LIMIT_MAX_REQUESTS` | Max requests per window | `100` |

## Development

### Scripts

```bash
# Start development server
npm run dev

# Start production server
npm start

# Run tests
npm test

# Seed database
npm run seed
```

### Project Structure

```
backend/
├── config/
│   └── database.js          # Database configuration
├── middleware/
│   ├── auth.js              # Authentication middleware
│   ├── errorHandler.js      # Error handling middleware
│   └── notFound.js          # 404 middleware
├── routes/
│   ├── auth.js              # Authentication routes
│   ├── users.js             # User management routes
│   ├── workouts.js          # Workout routes
│   ├── exercises.js         # Exercise routes
│   ├── nutrition.js         # Nutrition routes
│   └── progress.js          # Progress routes
├── utils/
│   └── validation.js        # Validation utilities
├── data/                    # JSON data files
├── uploads/                 # File uploads
├── server.js                # Main server file
├── package.json
└── README.md
```

## Security Features

- **JWT Authentication**: Secure token-based authentication
- **Password Hashing**: bcryptjs for password security
- **Rate Limiting**: Prevent abuse with request limiting
- **Input Validation**: Comprehensive request validation
- **CORS Protection**: Cross-origin resource sharing protection
- **Security Headers**: Helmet.js for security headers
- **Account Locking**: Automatic account lockout after failed attempts

## Error Handling

The API includes comprehensive error handling:

- **400**: Bad Request (validation errors)
- **401**: Unauthorized (authentication required)
- **403**: Forbidden (insufficient permissions)
- **404**: Not Found (resource not found)
- **409**: Conflict (duplicate data)
- **429**: Too Many Requests (rate limit exceeded)
- **500**: Internal Server Error

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

MIT License - see LICENSE file for details

## Support

For support and questions, please open an issue in the repository. 