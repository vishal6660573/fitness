#!/usr/bin/env node

import { initializeDatabase } from './config/database.js';
import seedDatabase from './scripts/seed.js';

const startApplication = async () => {
  try {
    console.log('🚀 Starting FitHub Backend...');
    
    // Initialize database
    await initializeDatabase();
    
    // Seed database with initial data
    await seedDatabase();
    
    console.log('\n✅ Backend is ready!');
    console.log('📝 Next steps:');
    console.log('   1. Create a .env file with your configuration');
    console.log('   2. Run: npm run dev');
    console.log('   3. Test the API at: http://localhost:5000/api/health');
    
  } catch (error) {
    console.error('❌ Failed to start application:', error);
    process.exit(1);
  }
};

startApplication(); 